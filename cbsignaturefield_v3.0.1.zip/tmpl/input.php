<?php
$value = isset($user->{$field->name}) ? $user->{$field->name} : '';
?>
<div class="cb-signaturefield" data-field="<?php echo htmlspecialchars($field->name); ?>">
  <?php if (!empty($value)) : ?>
    <div style="margin-bottom:8px;">
      <strong>Current signature:</strong><br>
      <img src="/<?php echo htmlspecialchars($value); ?>" alt="Existing signature" style="max-width:100%;height:auto;border:1px solid #ccc;" />
    </div>
  <?php endif; ?>

  <canvas id="<?php echo $field->name; ?>_canvas"
          width="600"
          height="<?php echo (int) $cfg->height; ?>"
          style="display:block;width:100%;max-width:100%;border:1px solid #ccc;background:<?php echo htmlspecialchars($cfg->bgColor); ?>;">
  </canvas>

  <div style="margin-top:6px;display:flex;gap:8px;flex-wrap:wrap;">
    <button type="button" onclick="CBSign && CBSign.clear('<?php echo $field->name; ?>')">Clear</button>
    <button type="button" onclick="CBSign && CBSign.loadExisting('<?php echo $field->name; ?>','/<?php echo htmlspecialchars($value ?: ''); ?>')"<?php echo empty($value)?' disabled':''; ?>>Load Existing</button>
  </div>

  <input type="hidden" name="<?php echo $field->name; ?>__sigdata" id="<?php echo $field->name; ?>__sigdata" value="">

  <script src="/components/com_comprofiler/plugin/user/plug_cbsignaturefield/media/signature.js"></script>
  <script>
    (function(){
      if(!window.CBSign) return;
      CBSign.init('<?php echo $field->name; ?>', { penWidth: <?php echo (int) $cfg->penWidth; ?>, penColor: '<?php echo htmlspecialchars($cfg->penColor); ?>' });
      var form = document.querySelector('form');
      if(form && !form.__cbsignBound){
        form.__cbsignBound = true;
        form.addEventListener('submit', function(){ CBSign.exportPNG('<?php echo $field->name; ?>'); });
      }
    })();
  </script>
</div>

<?php
if ( ! ( defined('CBLIB') || defined('_JEXEC') ) ) { die('Restricted access'); }

use CB\Plugin\Signature\Field\SignatureField;

if ( class_exists('AutoLoader') && method_exists('AutoLoader', 'registerExactMap') ) {
    AutoLoader::registerExactMap('%^CB/Plugin/Signature/(.+)%i', __DIR__ . '/library/$1.php');
}

global $_PLUGINS;
if ( isset($_PLUGINS) && is_object($_PLUGINS) ) {
    if ( method_exists($_PLUGINS, 'loadPluginGroup') ) { $_PLUGINS->loadPluginGroup('user'); }
    if ( method_exists($_PLUGINS, 'registerUserFieldParams') ) { $_PLUGINS->registerUserFieldParams(); }
    if ( method_exists($_PLUGINS, 'registerUserFieldTypes') ) {
        $_PLUGINS->registerUserFieldTypes([ 'signature' => SignatureField::class ]);
    }
}

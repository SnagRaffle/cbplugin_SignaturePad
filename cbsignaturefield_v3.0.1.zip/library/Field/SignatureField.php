<?php
namespace CB\Plugin\Signature\Field;

\defined('CBLIB') or \defined('_JEXEC') or die('Restricted access');

class SignatureField extends \cbFieldHandler
{
    public function getFieldTypes() {
        return [ 'signature' => [ 'name' => 'Signature' ] ];
    }

    public function drawField( &$field, &$user, $output, $reason, $list_compare_types, $html, $fieldId, $tab, $tabPane, $pluginParams ) {
        if ( $field->type != 'signature' ) { return null; }

        $params = method_exists($field, 'getParams') ? $field->getParams() : null;
        $cfg = [
            'height'   => $params ? (int) $params->get('height', 180) : 180,
            'penWidth' => $params ? (int) $params->get('penWidth', 2) : 2,
            'penColor' => $params ? (string) $params->get('penColor', '#111111') : '#111111',
            'bgColor'  => $params ? (string) $params->get('bgColor', '#ffffff') : '#ffffff',
            'storePath'=> $params ? (string) $params->get('storePath', 'images/comprofiler/signatures') : 'images/comprofiler/signatures',
        ];

        $cfg = (object) $cfg;
        $value = isset($user->{$field->name}) ? $user->{$field->name} : '';

        ob_start();
        include __DIR__ . '/../../tmpl/input.php';
        return ob_get_clean();
    }

    public function onBeforeUserProfileSave( &$field, &$user, $isNew, $oldUser, $reason ) {
        if ( $field->type != 'signature' ) { return true; }

        $fieldName = $field->name;
        $postKey   = $fieldName . '__sigdata';
        $dataUrl   = isset($_POST[$postKey]) ? $_POST[$postKey] : '';

        if ( ! $dataUrl || strpos($dataUrl, 'data:image/png;base64,') !== 0 ) {
            return true;
        }

        $params    = method_exists($field, 'getParams') ? $field->getParams() : null;
        $storeRel  = $params ? (string) $params->get('storePath', 'images/comprofiler/signatures') : 'images/comprofiler/signatures';
        $storeRel  = trim($storeRel, '/');
        $storeAbs  = rtrim(\JPATH_ROOT, '/') . '/' . $storeRel;

        if ( ! is_dir($storeAbs) ) {
            @mkdir($storeAbs, 0755, true);
            if ( ! is_dir($storeAbs) ) {
                return false;
            }
        }

        $userId = isset($user->id) ? (int) $user->id : 0;
        $ts     = gmdate('Ymd_His');
        $fname  = $userId . '_' . $fieldName . '_' . $ts . '.png';
        $abs    = $storeAbs . '/' . $fname;
        $rel    = $storeRel . '/' . $fname;

        $raw = base64_decode( substr($dataUrl, strlen('data:image/png;base64,')) );
        if ($raw === false) { return false; }
        if (@file_put_contents($abs, $raw) === false) { return false; }

        $user->$fieldName = $rel;
        return true;
    }
}

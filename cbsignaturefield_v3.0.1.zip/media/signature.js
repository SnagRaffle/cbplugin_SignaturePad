window.CBSign = (function(){
  var pads = {};
  function init(name, opts){
    var c = document.getElementById(name + '_canvas'); if(!c) return;
    var ctx = c.getContext('2d');
    var drawing = false, last = null;
    ctx.lineWidth = opts.penWidth || 2;
    ctx.strokeStyle = opts.penColor || '#111111';
    ctx.lineCap = 'round';
    function pos(e){ var r=c.getBoundingClientRect(); var t=e.touches&&e.touches[0]; return {x:(t?t.clientX:e.clientX)-r.left,y:(t?t.clientY:e.clientY)-r.top}; }
    function start(e){ drawing=true; last=pos(e); e.preventDefault(); }
    function move(e){ if(!drawing) return; var p=pos(e); ctx.beginPath(); ctx.moveTo(last.x,last.y); ctx.lineTo(p.x,p.y); ctx.stroke(); last=p; e.preventDefault(); }
    function end(){ drawing=false; }
    c.addEventListener('mousedown', start); c.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
    c.addEventListener('touchstart', start, {passive:false}); c.addEventListener('touchmove', move, {passive:false}); c.addEventListener('touchend', end);
    pads[name]={canvas:c};
  }
  function clear(name){ var p=pads[name]; if(!p) return; var c=p.canvas,ctx=c.getContext('2d'); ctx.clearRect(0,0,c.width,c.height); }
  function loadExisting(name, url){ var p=pads[name]; if(!p||!url) return; var c=p.canvas,ctx=c.getContext('2d'); var img=new Image(); img.onload=function(){ ctx.drawImage(img,0,0,Math.min(c.width,img.width),Math.min(c.height,img.height)); }; img.src=url; }
  function exportPNG(name){ var p=pads[name]; if(!p) return; var c=pads[name].canvas; var data=c.toDataURL('image/png'); var hid=document.getElementById(name+'__sigdata'); if(hid) hid.value=data; }
  return { init:init, clear:clear, loadExisting:loadExisting, exportPNG:exportPNG };
})();
<?php
/**
* Community Builder (TM) cbprogressfield Default (English) language file Frontend
* @version $Id:$
* @copyright (C) 2004-2024 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

/**
* WARNING:
* Do not make changes to this file as it will be over-written when you upgrade CB.
* To localize you need to create your own CB language plugin and make changes there.
*/

defined('CBLIB') or die();

return	array(
// 26 language strings from file plug_cbprogressfield/cbprogressfield.xml
'SELECT_TEMPLATE_TO_BE_USED_FOR_THIS_PROGRESS_DISPL_47013b'	=>	'Select template to be used for this progress display. If template is incomplete then missing files will be used from the default template. Template files can be located at the following location: components/com_comprofiler/plugin/user/plug_cbprogressfield/templates/.',
'SAME_AS_GLOBAL_540a68'	=>	'Same as Global',
'SELECT_THE_FIELDS_TO_BE_USED_IN_PROGRESS_CALCULATI_22bdf5'	=>	'Select the fields to be used in progress calculation. All fields progress is calculated automatically from a scale of 100 percent.',
'FIELDS_a4ca5e'	=>	'Fields',
'HIDE_ON_COMPLETE_a4bf17'	=>	'Hide on Complete',
'ENABLE_OR_DISABLE_DISPLAY_OF_PROGRESS_FIELD_TO_USE_73a3f0'	=>	'Enable or disable display of progress field to users self only. Moderators are exempt and can always see progress.',
'PRIVATE_DISPLAY_3ceb3f'	=>	'Private Display',
'DISPLAY_COMPLETE_90925a'	=>	'Display % Complete',
'STRIPED_55b590'	=>	'Striped',
'THIS_IS_SUBJECT_TO_USER_BROWSER_AND_DEVICE_PREFERE_8b9f29'	=>	'This is subject to user browser and device preference. If browser is set to reduced motion the progress bar will not animate.',
'ANIMATED_0a21b9'	=>	'Animated',
'OPTIONALLY_SUPPLY_A_CUSTOM_HEIGHT_FOR_THE_PROGRESS_49a1de'	=>	'Optionally supply a custom height for the progress bar in pixels (e.g. for 20px height simply supply a value of 20).',
'HEIGHT_eec6c4'	=>	'Height',
'COLORS_5d5088'	=>	'Colors',
'INPUT_THE_PERCENTAGE_COMPLETE_AS_AN_INTEGER_FOR_WH_f739af'	=>	'Input the percentage complete as an integer for when this color starts applying.',
'COMPLETE_7ca139'	=>	'% Complete',
'COLOR_cb5feb'	=>	'Color',
'007BFF_cd820b'	=>	'#007bff',
'HIDE_62a5e4'	=>	'Hide',
'SHOW_COMPLETE_3225f8'	=>	'Show Complete',
'SHOW_INCOMPLETE_627197'	=>	'Show InComplete',
'SHOW_COMPLETE_INCOMPLETE_b16adb'	=>	'Show Complete & InComplete',
'THIS_WILL_LINK_DIRECTLY_TO_PROFILE_EDIT_THE_TAB_TH_a9818d'	=>	'This will link directly to profile edit, the tab the field is on, and try to focus the field. This can help users find what they need to complete quicker.',
'INCOMPLETE_FIELD_LINKS_a4644a'	=>	'Incomplete Field Links',
'COLUMNS_168b82'	=>	'Columns',
'SELECT_TEMPLATE_TO_BE_USED_FOR_ALL_OF_CB_PROGRESS__fb051f'	=>	'Select template to be used for all of CB Progress Field. If template is incomplete then missing files will be used from the default template. Template files can be located at the following location: components/com_comprofiler/plugin/user/plug_cbprogressfield/templates/.',
// 1 language strings from file plug_cbprogressfield/templates/default/progress.php
'PROFILE_COMPLETE_PERCENT'	=>	'[complete]%',
);

<?php
/**
* Community Builder (TM) cbprogressfield Default (English) language file Administration
* @version $Id:$
* @copyright (C) 2004-2024 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

/**
* WARNING:
* Do not make changes to this file as it will be over-written when you upgrade CB.
* To localize you need to create your own CB language plugin and make changes there.
*/

defined('CBLIB') or die();

return	array(
// 3 language strings from file plug_cbprogressfield/cbprogressfield.xml
'PROGRESS_46b5f8'	=>	'Progress',
'PROGRESS_BAR_8e4a53'	=>	'Progress Bar',
'CHECKLIST_a5d727'	=>	'Checklist',
);

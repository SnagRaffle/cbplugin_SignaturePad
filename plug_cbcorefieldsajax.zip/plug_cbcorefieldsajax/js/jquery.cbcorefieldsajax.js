(function($) {
	const instances = [];
	const httpCache = {};
	const methods = {
		init: function( options ) {
			return this.each( function () {
				const $this = this;
				let cbajaxfield = $( $this ).data( 'cbajaxfield' );

				if ( cbajaxfield ) {
					return; // cbajaxfield is already bound; so no need to rebind below
				}

				cbajaxfield = {};
				cbajaxfield.options = options;
				cbajaxfield.defaults = $.fn.cbajaxfield.defaults;
				cbajaxfield.settings = $.extend( true, {}, cbajaxfield.defaults, cbajaxfield.options );
				cbajaxfield.element = $( $this );
				cbajaxfield.values = {};

				if ( cbajaxfield.settings.useData ) {
					$.each( cbajaxfield.defaults, function( key, value ) {
						if ( ( key !== 'init' ) && ( key !== 'useData' ) ) {
							// Dash Separated:
							let dataValue = cbajaxfield.element.data( 'cbajaxfield' + key.charAt( 0 ).toUpperCase() + key.slice( 1 ) );

							if ( typeof dataValue != 'undefined' ) {
								cbajaxfield.settings[key] = dataValue;
							} else {
								// No Separater:
								dataValue = cbajaxfield.element.data( 'cbajaxfield' + key.charAt( 0 ).toUpperCase() + key.slice( 1 ).toLowerCase() );

								if ( typeof dataValue != 'undefined' ) {
									cbajaxfield.settings[key] = dataValue;
								}
							}
						}
					});
				}

				cbajaxfield.element.trigger( 'cbajaxfield.init.before', [cbajaxfield] );

				if ( ! cbajaxfield.settings.init ) {
					return;
				}

				$.ajaxPrefilter( function( options, originalOptions, jqXHR ) {
					options.async = true;
				});

				if ( cbajaxfield.settings.mode === 'update' ) {
					if ( ! ( cbajaxfield.settings.selectors || $( cbajaxfield.settings.selectors ).length ) ) {
						return;
					}

					cbajaxfield.repeat = cbajaxfield.element.closest( '.cbRepeatRow' ).length;

					if ( ( cbajaxfield.settings.post === null ) || ( ( typeof cbajaxfield.settings.post != 'object' ) && ( ! $.isArray( cbajaxfield.settings.post ) ) ) ) {
						cbajaxfield.settings.post = {};
					}

					cbajaxfield.timer = null;

					const ajaxResponse = function( data, field ) {
						cbajaxfield.element.removeClass( 'cbValidationError has-error' );
						cbajaxfield.element.find( '.cbValidationMessage' ).remove();

						if ( data === ' ' ) {
							cbajaxfield.element.addClass( 'hidden cbAjaxUpdateEmpty' );

							field.html( '' );
						} else {
							if ( ! cbajaxfield.element.hasClass( 'cbDisplayDisabled' ) ) {
								cbajaxfield.element.removeClass( 'hidden' );
							}

							cbajaxfield.element.removeClass( 'cbAjaxUpdateEmpty' );

							const editHtml = $( '<div></div>' ).html( data );
							const editScripts = parseHeaders.call( editHtml );

							field.html( editHtml.html() );

							cbajaxfield.element.triggerHandler( 'rebind', ['ajaxUpdateTarget'] );
							cbajaxfield.element.find( 'select,input,textarea' ).removeClass( '.cbValidationError' ).triggerHandler( 'change' );

							parseScripts.call( cbajaxfield.element, editScripts );
							rebindScripts.call( cbajaxfield.element );
						}

						cbajaxfield.element.triggerHandler( 'cbajaxfield.update.success', [cbajaxfield, data] );
					};

					cbajaxfield.changeHandler = function( event ) {
						if ( ( typeof event.data.ajaxUpdateTarget == 'undefined' ) || cbajaxfield.element.hasClass( 'cbAjaxUpdating' ) || cbajaxfield.element.hasClass( 'cbDisplayDisabled' ) ) {
							return;
						}

						const tab = cbajaxfield.element.closest( '.cbTabPane' );

						if ( tab.length && tab.hasClass( 'cbDisplayDisabled' ) ) {
							return;
						}

						const post = cbajaxfield.settings.post;
						const instant = ( event.type === 'instant' );
						let name = '';
						let value = '';

						if ( ! instant ) {
							name = $( this ).attr( 'name' );
							value = getValue.call( this );

							if ( ! name.length ) {
								return;
							}

							// Add the current field being changed to the POST:
							post[name] = value;

							if ( cbajaxfield.repeat ) {
								const repeatName = name.replace( /^.+__\d+__/g, '' );

								if ( name !== repeatName ) {
									// CB Repeat name is available so lets be sure we also send the original field values for substitutions:
									post[repeatName] = value;
								}
							}
						}

						// Add the other fields that Update On is depending on to the POST:
						$( cbajaxfield.settings.selectors ).filter( function() {
							if ( cbajaxfield.repeat && $( this ).closest( '.cbRepeatRow' ).length ) {
								// CB Repeat is being used and this element is inside a repeat usage so make sure it belongs to the current one
								return cbajaxfield.element.siblings().is( $( this ) );
							}

							return true;
						}).each( function() {
							const updateTarget = findTarget.call( this );

							if ( ! updateTarget.length ) {
								return true;
							}

							const updateName = updateTarget.attr( 'name' );

							if ( ( ! instant ) && ( updateName === name ) ) {
								return true;
							}

							if ( updateName.length ) {
								post[updateName] = getValue.call( updateTarget );

								if ( cbajaxfield.repeat ) {
									const updateRepeatName = updateName.replace( /^.+__\d+__/g, '' );

									if ( updateName !== updateRepeatName ) {
										post[updateRepeatName] = post[updateName];
									}
								}
							}
						});

						// Add the field being updated to the POST:
						const target = findTarget.call( cbajaxfield.element );

						if ( target.length ) {
							const targetName = target.attr( 'name' );
							const targetValue = getValue.call( target );

							if ( targetName.length ) {
								post[targetName] = targetValue;

								if ( cbajaxfield.repeat ) {
									// We are in a repeat usage so the field in GET will no longer match so lets override it via POST:
									post['field'] = targetName;

									const targetRepeatName = targetName.replace( /^.+__\d+__/g, '' );

									if ( targetName !== targetRepeatName ) {
										post[targetRepeatName] = post[targetName];
									}
								}
							}
						}

						let field = cbajaxfield.element.find( '.cb_field > div:first' );

						if ( ! field.length ) {
							field = cbajaxfield.element.find( '.cb_field > span:first' );
						}

						if ( ! field.length ) {
							field = cbajaxfield.element;
						}

						let updateCacheUrl = new URL( cbajaxfield.settings.url, document.baseURI );

						$.each( post, function( postKey, postValue ) {
							updateCacheUrl.searchParams.set( postKey, postValue );
						});

						if ( updateCacheUrl in httpCache ) {
							ajaxResponse( httpCache[updateCacheUrl], field );

							return;
						}

						let timerDelay = 200;

						if ( event.type === 'keyup' ) {
							timerDelay = 400;
						} else if ( instant ) {
							timerDelay = 0;
						}

						if ( cbajaxfield.timer ) {
							clearTimeout( cbajaxfield.timer );
						}

						cbajaxfield.timer = setTimeout( function() {
							if ( cbajaxfield.element.hasClass( 'cbAjaxUpdating' ) ) {
								return;
							}

							if ( ! instant ) {
								if ( typeof cbajaxfield.values[name] != 'undefined' ) {
									const oldValue = ( $.isArray( cbajaxfield.values[name] ) ? cbajaxfield.values[name].toString() : cbajaxfield.values[name] );
									const newValue = ( $.isArray( value ) ? value.toString() : value );

									if ( oldValue === newValue ) {
										return;
									}
								}

								cbajaxfield.values[name] = value;
							}

							$.ajax({
								url: cbajaxfield.settings.url,
								type: 'POST',
								dataType: 'html',
								cache: false,
								data: post,
								beforeSend: function( jqXHR, textStatus, errorThrown ) {
									cbajaxfield.element.addClass( 'cbAjaxUpdating' );
									cbajaxfield.element.find( '.cbAjaxUpdate' ).remove();

									if ( ( ! target.length ) || ( target.is( ':checkbox' ) || target.is( ':radio' ) ) ) {
										field.append( '<span class="cbFieldIcons cbAjaxUpdate"><div class="cbSpinner"><span class="cbSpinnerIcon spinner-border spinner-border-sm text-secondary"></span></div></span>' );
									} else {
										target.after( '<span class="cbFieldIcons cbAjaxUpdate"><div class="cbSpinner"><span class="cbSpinnerIcon spinner-border spinner-border-sm text-secondary"></span></div></span>' );
									}

									cbajaxfield.element.triggerHandler( 'cbajaxfield.update.send', [cbajaxfield, jqXHR, textStatus, errorThrown] );
								},
								error: function( jqXHR, textStatus, errorThrown ) {
									cbajaxfield.element.removeClass( 'cbAjaxUpdating' );
									cbajaxfield.element.find( '.cbAjaxUpdate' ).remove();

									cbajaxfield.element.triggerHandler( 'cbajaxfield.update.error', [cbajaxfield, jqXHR, textStatus, errorThrown] );
								},
								success: function( data, textStatus, jqXHR ) {
									httpCache[updateCacheUrl] = data;

									cbajaxfield.element.removeClass( 'cbAjaxUpdating' );
									cbajaxfield.element.find( '.cbAjaxUpdate' ).remove();

									ajaxResponse( data, field );
								}
							});
						}, timerDelay );
					};

					cbajaxfield.element.on( 'cbconditional.show', function() {
						cbajaxfield.changeHandler( { data: { ajaxUpdateTarget: cbajaxfield.element }, type: 'instant' } );
					});

					if ( cbajaxfield.settings.reason === 'profile' ) {
						$( cbajaxfield.settings.selectors ).on( 'cbajaxfield.save.success', function() {
							if ( cbajaxfield.element.hasClass( 'cbAjaxUpdating' ) ) {
								return;
							}

							$.ajax({
								url: cbajaxfield.settings.url,
								type: 'GET',
								dataType: 'html',
								cache: false,
								beforeSend: function( jqXHR, textStatus, errorThrown ) {
									cbajaxfield.element.addClass( 'cbAjaxUpdating' );
									cbajaxfield.element.triggerHandler( 'cbajaxfield.update.send', [cbajaxfield, jqXHR, textStatus, errorThrown] );
								},
								error: function( jqXHR, textStatus, errorThrown ) {
									cbajaxfield.element.removeClass( 'cbAjaxUpdating' );
									cbajaxfield.element.triggerHandler( 'cbajaxfield.update.error', [cbajaxfield, jqXHR, textStatus, errorThrown] );
								},
								success: function( data, textStatus, jqXHR ) {
									cbajaxfield.element.removeClass( 'cbAjaxUpdating' );

									const displayHtml = $( '<div></div>' ).html( data );
									const displayScripts = parseHeaders.call( displayHtml );

									let field = cbajaxfield.element.find( '> .cb_field > *:first > .cbAjaxContainerDisplay > .cbAjaxValue' );

									if ( ! field.length ) {
										field = cbajaxfield.element.find( '> .cb_field > div:first' );
									}

									if ( ! field.length ) {
										field = cbajaxfield.element.find( '> .cb_field > span:first' );
									}

									field.html( displayHtml.html() );

									parseScripts.call( cbajaxfield.element, displayScripts );
									rebindScripts.call( cbajaxfield.element );
								}
							});
						});
					} else {
						$( cbajaxfield.settings.selectors ).filter( function() {
							if ( cbajaxfield.repeat && $( this ).closest( '.cbRepeatRow' ).length ) {
								// CB Repeat is being used and this element is inside a repeat usage so make sure it belongs to the current one
								return cbajaxfield.element.siblings().is( $( this ) );
							}

							return true;
						}).each( function() {
							let target = findTarget.call( this );

							if ( ! target.length ) {
								return true;
							}

							const name = target.attr( 'name' );

							if ( name.length ) {
								cbajaxfield.values[name] = getValue.call( target );
							}

							target.on( 'keyup change', {ajaxUpdateTarget: this}, cbajaxfield.changeHandler );

							// The target element is being told to rebind so lets rebind its change handler:
							$( this ).on( 'rebind.cbajaxfieldtarget', function() {
								// clear any existing bindings just encase to avoid double binding:
								target.off( 'keyup change', cbajaxfield.changeHandler );

								// redo the binding:
								target = findTarget.call( this );

								if ( ! target.length ) {
									return;
								}

								target.on( 'keyup change', {ajaxUpdateTarget: this}, cbajaxfield.changeHandler );
							});
						});
					}
				} else {
					cbajaxfield.editHandler = function( e ) {
						if ( ( ! cbajaxfield.element.hasClass( 'cbAjaxEditing' ) ) && ( $( e.target ).hasClass( 'cbAjaxToggle' ) || $( e.target ).hasClass( 'cbAjaxIcon' ) || ( ! cbajaxfield.settings.ignore ) || ( cbajaxfield.settings.ignore && ( ! $( e.target ).is( cbajaxfield.settings.ignore ) ) && ( ! $( e.target ).parents().is( cbajaxfield.settings.ignore ) ) ) ) ) {
							cbajaxfield.element.addClass( 'cbAjaxEditing' );

							let url = cbajaxfield.settings.url;

							if ( ! url ) {
								url = $( this ).attr( 'href' );
							}

							let width = cbajaxfield.element.innerWidth();

							if ( width < 300 ) {
								width = 400;
							}

							const mode = ( ( cbajaxfield.settings.mode !== 'tooltip' ) && ( cbajaxfield.settings.mode !== 'modal' ) || ( ! $.fn.cbtooltip ) ? 'inline' : cbajaxfield.settings.mode );

							$.ajax({
								url: url,
								type: 'GET',
								dataType: 'html',
								cache: false,
								beforeSend: function( jqXHR, textStatus, errorThrown ) {
									$( document ).find( '.cbAjaxCancel' ).click();
									cbajaxfield.element.addClass( 'cbAjaxEditLoading' );
									cbajaxfield.element.append( '<div class="cbSpinner"><span class="cbSpinnerIcon spinner-border spinner-border-sm text-secondary"></span></div>' );

									if ( mode === 'inline' ) {
										cbajaxfield.element.find( '.cbAjaxValue' ).addClass( 'hidden' );
									}

									cbajaxfield.element.triggerHandler( 'cbajaxfield.edit.send', [cbajaxfield, jqXHR, textStatus, errorThrown] );
								},
								error: function( jqXHR, textStatus, errorThrown ) {
									cbajaxfield.element.removeClass( 'cbAjaxEditing' );
									cbajaxfield.element.removeClass( 'cbAjaxEditLoading' );
									cbajaxfield.element.find( '.cbAjaxForm,.cbSpinner' ).remove();

									if ( mode === 'inline' ) {
										cbajaxfield.element.find( '.cbAjaxValue' ).removeClass( 'hidden' );
									}

									cbajaxfield.element.triggerHandler( 'cbajaxfield.edit.error', [cbajaxfield, jqXHR, textStatus, errorThrown] );
								},
								success: function( data, textStatus, jqXHR ) {
									cbajaxfield.element.removeClass( 'cbAjaxEditLoading' );
									cbajaxfield.element.find( '.cbSpinner' ).remove();

									if ( mode === 'inline' ) {
										cbajaxfield.element.find( '.cbAjaxValue' ).removeClass( 'hidden' );
									}

									const editHtml = $( data );
									const editScripts = parseHeaders.call( editHtml );
									let tooltip = null;

									if ( mode === 'inline' ) {
										cbajaxfield.element.addClass( 'hidden' );
										cbajaxfield.element.after( editHtml );
									} else if ( mode === 'tooltip' ) {
										tooltip = $( '<div></div>' ).cbtooltip({
											tooltip: editHtml,
											openReady: true,
											positionMy: 'top left',
											positionAt: 'top left',
											positionTarget: cbajaxfield.element,
											adjustMethod: 'none',
											openEvent: 'none',
											closeEvent: 'none',
											dialog: true,
											buttonClose: false,
											width: width,
											height: 'auto',
											classes: ( $.fn.cbtooltip.defaults.classes ? $.fn.cbtooltip.defaults.classes : '' ) + ( cbajaxfield.settings.classes ? ' ' + cbajaxfield.settings.classes : '' ) + ' cbAjaxTooltip'
										});
									} else if ( mode === 'modal' ) {
										tooltip = $( '<div></div>' ).cbtooltip({
											tooltip: editHtml,
											openReady: true,
											openEvent: 'none',
											closeEvent: 'none',
											modal: true,
											dialog: true,
											buttonClose: false,
											width: '98%',
											height: '98%',
											classes: ( $.fn.cbtooltip.defaults.classes ? $.fn.cbtooltip.defaults.classes : '' ) + ( cbajaxfield.settings.classes ? ' ' + cbajaxfield.settings.classes : '' ) + ' cbAjaxModal qtip-nostyle'
										});
									}

									const renderDone = function( newHtml ) {
										parseScripts.call( newHtml, editScripts );
										rebindScripts.call( newHtml );

										loadCMSScripts( newHtml );

										if ( tooltip ) {
											tooltip.on( 'cbtooltip.hidden', function() {
												cbajaxfield.element.removeClass( 'cbAjaxEditing' );

												tooltip = null;

												cbajaxfield.element.trigger( 'cbajaxfield.cancel', [cbajaxfield, e] );
											});

											if ( tooltip.qtip( 'api' ).elements.tooltip ) {
												tooltip.qtip( 'api' ).elements.tooltip.removeClass( 'cbAjaxTooltipLoading' );
											}

											if ( tooltip.qtip( 'api' ).elements.overlay ) {
												tooltip.qtip( 'api' ).elements.overlay.removeClass( 'cbAjaxTooltipLoading' );
											}
										} else {
											newHtml.on( 'click', '.cbAjaxCancel', function( e ) {
												cbajaxfield.element.removeClass( 'cbAjaxEditing' );

												unloadCMSScripts( newHtml );

												if ( mode === 'inline' ) {
													newHtml.remove();
													cbajaxfield.element.find( '.cbSpinner' ).remove();
													cbajaxfield.element.removeClass( 'hidden' );
													cbajaxfield.element.find( '.cbAjaxValue' ).removeClass( 'hidden' );
												} else if ( tooltip ) {
													if ( mode === 'modal' ) {
														$( 'body' ).removeClass( 'cbTooltipModalOpen' );
													}

													tooltip.cbtooltip( 'destroy' );

													tooltip = null;
												}

												cbajaxfield.element.trigger( 'cbajaxfield.cancel', [cbajaxfield, e] );
											});
										}

										newHtml.find( '.cbAjaxForm' ).on( 'submit', function( e ) {
											e.preventDefault();

											saveCMSScripts( newHtml );

											$( this ).ajaxSubmit({
												type: 'POST',
												dataType: 'html',
												beforeSerialize: function( form, options ) {
													cbajaxfield.element.trigger( 'cbajaxfield.save.serialize', [cbajaxfield, form, options] );
												},
												beforeSubmit: function( formData, form, options ) {
													const validator = newHtml.find( '.cbAjaxForm' ).data( 'cbvalidate' );

													if ( validator ) {
														if ( ! validator.element.cbvalidate( 'validate' ) ) {
															return false;
														}
													}

													cbajaxfield.element.addClass( 'cbAjaxEditSaving' );
													cbajaxfield.element.append( '<div class="cbSpinner"><span class="cbSpinnerIcon spinner-border spinner-border-sm text-secondary"></span></div>' );

													if ( mode === 'inline' ) {
														if ( cbajaxfield.element.hasClass( 'cbAjaxContainerTab' ) ) {
															newHtml.find( '.cbAjaxButtons' ).addClass( 'hidden' );
														} else {
															newHtml.addClass( 'hidden' );
														}

														cbajaxfield.element.removeClass( 'hidden' );
														cbajaxfield.element.find( '.cbAjaxValue' ).addClass( 'hidden' );
													} else if ( tooltip ) {
														if ( mode === 'modal' ) {
															$( 'body' ).removeClass( 'cbTooltipModalOpen' );
														}

														if ( tooltip.qtip( 'api' ).elements.tooltip ) {
															tooltip.qtip( 'api' ).elements.tooltip.addClass( 'cbAjaxTooltipLoading' );
														}

														if ( tooltip.qtip( 'api' ).elements.overlay ) {
															tooltip.qtip( 'api' ).elements.overlay.addClass( 'cbAjaxTooltipLoading' );
														}
													}

													cbajaxfield.element.trigger( 'cbajaxfield.save.submit', [cbajaxfield, formData, form, options] );
												},
												error: function( jqXHR, textStatus, errorThrown ) {
													cbajaxfield.element.removeClass( 'cbAjaxEditing' );
													cbajaxfield.element.removeClass( 'cbAjaxEditSaving' );
													cbajaxfield.element.find( '.cbSpinner' ).remove();

													unloadCMSScripts( newHtml );

													if ( mode === 'inline' ) {
														newHtml.remove();
														cbajaxfield.element.find( '.cbAjaxValue' ).removeClass( 'hidden' );
													} else if ( tooltip ) {
														if ( mode === 'modal' ) {
															$( 'body' ).removeClass( 'cbTooltipModalOpen' );
														}

														tooltip.cbtooltip( 'destroy' );

														tooltip = null;
													}

													cbajaxfield.element.trigger( 'cbajaxfield.save.error', [cbajaxfield, jqXHR, textStatus, errorThrown] );
												},
												success: function( data, textStatus, jqXHR ) {
													cbajaxfield.element.removeClass( 'cbAjaxEditSaving' );
													cbajaxfield.element.find( '.cbSpinner' ).remove();

													const displayHtml = $( '<div></div>' ).html( data );

													if ( displayHtml.find( '.cbAjaxError' ).length ) {
														newHtml.children( '.alert' ).remove();
														newHtml.prepend( displayHtml );

														if ( mode === 'inline' ) {
															if ( cbajaxfield.element.hasClass( 'cbAjaxContainerTab' ) ) {
																newHtml.find( '.cbAjaxButtons' ).removeClass( 'hidden' );
															} else {
																newHtml.removeClass( 'hidden' );
															}

															cbajaxfield.element.addClass( 'hidden' );
														} else if ( tooltip ) {
															if ( mode === 'modal' ) {
																$( 'body' ).addClass( 'cbTooltipModalOpen' );
															}

															if ( tooltip.qtip( 'api' ).elements.tooltip ) {
																tooltip.qtip( 'api' ).elements.tooltip.removeClass( 'cbAjaxTooltipLoading' );
															}

															if ( tooltip.qtip( 'api' ).elements.overlay ) {
																tooltip.qtip( 'api' ).elements.overlay.removeClass( 'cbAjaxTooltipLoading' );
															}

															tooltip.cbtooltip( 'reposition' );
														}
													} else {
														cbajaxfield.element.removeClass( 'cbAjaxEditing' );

														unloadCMSScripts( newHtml );

														if ( mode === 'inline' ) {
															newHtml.remove();
															cbajaxfield.element.find( '.cbAjaxValue' ).removeClass( 'hidden' );
														} else if ( tooltip ) {
															if ( mode === 'modal' ) {
																$( 'body' ).removeClass( 'cbTooltipModalOpen' );
															}

															tooltip.cbtooltip( 'destroy' );

															tooltip = null;
														}

														const displayScripts = parseHeaders.call( displayHtml );
														let displayElement;

														if ( cbajaxfield.element.hasClass( 'cbAjaxContainerTab' ) ) {
															cbajaxfield.element.siblings( '.cbFieldsContentsTab' ).replaceWith( displayHtml.html() );

															displayElement = cbajaxfield.element.parent();
														} else {
															displayElement = cbajaxfield.element.find( '.cbAjaxValue' );

															displayElement.html( displayHtml.html() );
														}

														parseScripts.call( displayElement, displayScripts );
														rebindScripts.call( displayElement );
													}

													cbajaxfield.element.trigger( 'cbajaxfield.save.success', [cbajaxfield, data, textStatus, jqXHR] );
												}
											});

											return false;
										});

										cbajaxfield.element.triggerHandler( 'cbajaxfield.edit.success', [cbajaxfield, data, textStatus, jqXHR] );
									}

									if ( tooltip ) {
										tooltip.on( 'cbtooltip.render', function( e, cbtooltip, event, api ) {
											renderDone( api.elements.content );
										});
									} else {
										renderDone( editHtml );
									}
								}
							});
						}

						cbajaxfield.element.trigger( 'cbajaxfield.edit', [cbajaxfield, e] );
					};

					if ( cbajaxfield.element.hasClass( 'cbAjaxContainerToggle' ) ) {
						cbajaxfield.element.on( 'click', cbajaxfield.editHandler );
					} else {
						cbajaxfield.element.on( 'click', '.cbAjaxToggle', cbajaxfield.editHandler );
					}
				}

				// Destroy the cbajaxfield element:
				cbajaxfield.element.on( 'remove.cbajaxfield destroy.cbajaxfield', function() {
					cbajaxfield.element.cbajaxfield( 'destroy' );
				});

				// Rebind the cbajaxfield element to pick up any data attribute modifications:
				cbajaxfield.element.on( 'rebind.cbajaxfield', function( e, reason ) {
					if ( reason === 'ajaxUpdateTarget' ) {
						return;
					}

					cbajaxfield.element.cbajaxfield( 'rebind' );
				});

				// If the cbajaxfield element is modified we need to rebuild it to ensure all our bindings are still ok:
				cbajaxfield.element.on( 'modified.cbajaxfield', function( e, oldId, newId, index ) {
					if ( oldId !== newId ) {
						const urlAttr = cbajaxfield.element.attr( 'data-cbajaxfield-url' );

						if ( typeof urlAttr != 'undefined' ) {
							cbajaxfield.element.attr( 'data-cbajaxfield-url', urlAttr.replace( oldId, newId ) );
						}

						const urlData = cbajaxfield.element.data( 'cbajaxfield-url' );

						if ( typeof urlData != 'undefined' ) {
							cbajaxfield.element.data( 'cbajaxfield-url', urlData.replace( oldId, newId ) );
						}

						cbajaxfield.element.cbajaxfield( 'rebind' );
					}
				});

				// If the cbajaxfield is cloned we need to rebind it back:
				cbajaxfield.element.on( 'cloned.cbajaxfield', function() {
					destroyPlugin.call( this, cbajaxfield );

					$( this ).cbajaxfield( cbajaxfield.options );
				});

				cbajaxfield.element.trigger( 'cbajaxfield.init.after', [cbajaxfield] );

				// Bind the cbajaxfield to the element so it's reusable and chainable:
				cbajaxfield.element.data( 'cbajaxfield', cbajaxfield );

				// Add this instance to our instance array so we can keep track of our cbajaxfield instances:
				instances.push( cbajaxfield );
			});
		},
		rebind: function() {
			const cbajaxfield = $( this ).data( 'cbajaxfield' );

			if ( ! cbajaxfield ) {
				return this;
			}

			cbajaxfield.element.cbajaxfield( 'destroy' );
			cbajaxfield.element.cbajaxfield( cbajaxfield.options );

			return this;
		},
		destroy: function() {
			const cbajaxfield = $( this ).data( 'cbajaxfield' );

			if ( ! cbajaxfield ) {
				return false;
			}

			$.each( instances, function( i, instance ) {
				if ( instance.element === cbajaxfield.element ) {
					instances.splice( i, 1 );

					return false;
				}

				return true;
			});

			destroyPlugin.call( cbajaxfield.element, cbajaxfield );

			cbajaxfield.element.trigger( 'cbajaxfield.destroyed', [cbajaxfield] );

			return true;
		},
		instances: function() {
			return instances;
		}
	};

	function destroyPlugin( cbajaxfield ) {
		const element = ( this.jquery ? this : $( this ) );

		element.off( '.cbajaxfield' );

		if ( cbajaxfield.settings.mode === 'update' ) {
			element.off( '.cbajaxfieldtarget' );
			element.removeClass( 'cbAjaxUpdating' );
			element.find( '.cbAjaxUpdate' ).remove();

			if ( cbajaxfield.timer ) {
				clearTimeout( cbajaxfield.timer );
			}

			$( cbajaxfield.settings.selectors ).filter( function() {
				if ( cbajaxfield.repeat && $( this ).closest( '.cbRepeatRow' ).length ) {
					return element.siblings().is( $( this ) );
				}

				return true;
			}).each( function() {
				const target = findTarget.call( this );

				if ( ! target.length ) {
					return true;
				}

				target.off( 'keyup change', cbajaxfield.changeHandler );
			});
		} else {
			$( document ).find( '.cbAjaxCancel' ).click();

			element.find( '.cbAjaxValue' ).removeClass( 'hidden' );
			element.find( '.cbSpinner' ).remove();
			element.off( 'click', '.cbAjaxValue', cbajaxfield.editHandler );
		}

		element.removeData( 'cbajaxfield' );
	}

	function findTarget() {
		const element = ( this.jquery ? this : $( this ) );
		let target = null;

		if ( element.is( 'input' ) || element.is( 'select' ) || element.is( 'textarea' ) ) {
			target = element;
		} else {
			target = element.find( 'input,select,textarea' ).not( '[name$="__srmch"]' ).first();

			if ( target.is( ':checkbox' ) || target.is( ':radio' ) ) {
				target = element.find( 'input[name="' + target.attr( 'name' ) + '"]' );
			}
		}

		return target;
	}

	function getValue() {
		const element = ( this.jquery ? this : $( this ) );
		let value = null;

		if ( element.is( 'input' ) || element.is( 'select' ) || element.is( 'textarea' ) ) {
			if ( element.is( 'input[type="checkbox"]' ) || element.is( 'input[type="radio"]' ) ) {
				value = [];

				element.each( function() {
					if ( $( this ).is( ':checked' ) ) {
						value.push( $( this ).val() );
					}
				});
			} else if ( element.is( 'select[multiple]' ) ) {
				value = element.val();

				if ( value && ( ! $.isArray( value ) ) ) {
					value = value.split( ',' );
				}
			} else {
				value = element.val();
			}
		}

		return value;
	}

	function loadCMSScripts( html ) {
		let loadJoomlaTinyMCE = false;
		let loadJCE = false;

		try {
			html.find( 'textarea' ).each( function() {
				if ( $( this ).hasClass( 'joomla-editor-tinymce' ) ) {
					if ( ! ( window.Joomla && Joomla.JoomlaTinyMCE ) ) {
						return;
					}

					loadJoomlaTinyMCE = true;
				}

				if ( $( this ).hasClass( 'wf-editor' ) ) {
					if ( ! window.WFEditor ) {
						return;
					}

					loadJCE = true;
				}

				if ( $( this ).hasClass( 'codemirror-source' ) ) {
					if ( ! ( window.Joomla && window.Joomla.editors && Joomla.editors.instances && window.CodeMirror ) ) {
						return;
					}

					const input = $( this ).removeClass( 'codemirror-source' );
					const id = input.prop( 'id' );

					Joomla.editors.instances[id] = CodeMirror.fromTextArea( this, input.data( 'options' ) );
				}
			});

			if ( window.bootstrap && window.bootstrap.Modal ) {
				html.find( '.joomla-modal' ).each( function() {
					$( this ).appendTo( $( 'body' ) ).addClass( 'cbcorefieldsajax-modals' );

					if ( window.bootstrap.Modal.getInstance( this ) ) {
						return;
					}

					Joomla.initialiseModal( this, {
						isJoomla: true
					});
				});
			}

			if ( loadJoomlaTinyMCE ) {
				Joomla.JoomlaTinyMCE.setupEditors();
			}

			if ( loadJCE ) {
				if ( ! window.tinymce ) {
					window.tinymce.editors = [];
				}

				WFEditor.load();
			}

			html.get( 0 ).dispatchEvent( new CustomEvent( 'joomla:updated', {
				bubbles: true,
				cancelable: true
			}));
		} catch ( e ) {}
	}

	function saveCMSScripts( html ) {
		try {
			if ( html ) {
				html.find( 'textarea' ).each( function() {
					const editorName = $( this ).attr( 'name' );

					if ( window.Joomla
						&& window.Joomla.editors
						&& Joomla.editors.instances
						&& ( editorName in Joomla.editors.instances )
					) {
						Joomla.editors.instances[editorName].getValue();
					}
				});
			}

			if ( window.Joomla
				&& window.Joomla.editors
				&& Joomla.editors.instances
			) {
				for ( const jEditorKey in Joomla.editors.instances ) {
					const jEditor = Joomla.editors.instances[jEditorKey];

					if ( jEditor.constructor.name === 'CodeMirror' ) {
						jEditor.save();
					}
				}
			}

			if ( ( typeof tinyMCE !== 'undefined' ) && tinyMCE ) {
				tinyMCE.triggerSave();
			}
		} catch ( e ) {}
	}

	function unloadCMSScripts( html ) {
		try {
			if ( html ) {
				html.find( 'textarea' ).each( function() {
					const editorName = $( this ).attr( 'name' );

					if ( window.tinymce
						&& window.tinymce.editors
					) {
						if ( editorName in window.tinymce.editors ) {
							delete window.tinymce.editors[editorName];
						}

						for ( const tinyEditorKey in window.tinymce.editors ) {
							if ( window.tinymce.editors[tinyEditorKey].id === editorName ) {
								delete window.tinymce.editors[tinyEditorKey];
							}
						}
					}

					if ( window.Joomla
						&& window.Joomla.editors
						&& Joomla.editors.instances
					) {
						if ( editorName in Joomla.editors.instances ) {
							delete Joomla.editors.instances[editorName];
						}

						for ( const jEditorKey in Joomla.editors.instances ) {
							if ( Joomla.editors.instances[jEditorKey].id === editorName ) {
								delete Joomla.editors.instances[jEditorKey];
							}
						}
					}
				});
			}

			if ( ( typeof tinyMCE !== 'undefined' ) && tinyMCE ) {
				tinyMCE.remove();
			}

			const modals = $( 'body' ).children( '.cbcorefieldsajax-modals' );

			if ( modals.length ) {
				modals.remove();
			}
		} catch ( e ) {}
	}

	function removeEmptyHeaders() {
		const element = ( this.jquery ? this : $( this ) );
		let headers = element.find( '.cbAjaxHeaders' );

		if ( ! headers.length ) {
			headers = element.filter( '.cbAjaxHeaders' );
		}

		if ( ! headers.length ) {
			return;
		}

		if ( ( ! headers.length  ) || ( ! headers.children( 'link,script' ).length ) ) {
			headers.remove();
		}
	}

	function parseHeaders() {
		const element = ( this.jquery ? this : $( this ) );
		let headers = element.find( '.cbAjaxHeaders' );

		if ( ! headers.length ) {
			headers = element.filter( '.cbAjaxHeaders' );
		}

		if ( ! headers.length ) {
			return [];
		}

		const head = $( 'head' );
		const loadedCSS = [];
		const loadedScripts = [];

		head.find( 'link' ).each( function() {
			const cssUrl = $( this ).attr( 'href' );

			if ( cssUrl ) {
				loadedCSS.push( cssUrl )
			}
		});

		head.find( 'script' ).each( function() {
			const scriptUrl = $( this ).attr( 'src' );

			if ( scriptUrl ) {
				loadedScripts.push( scriptUrl )
			}
		});

		headers.children( 'link' ).each( function() {
			const cssUrl = $( this ).attr( 'href' );

			if ( ( ! cssUrl ) || ( loadedCSS.indexOf( cssUrl ) !== -1 ) ) {
				$( this ).remove();

				return;
			}

			const stylesheetPosition = $( 'head' ).find( 'link[href*="com_comprofiler"][rel="stylesheet"]' ).last();

			if ( ! stylesheetPosition.length ) {
				// CB isn't loaded so leave it as inline
				return;
			}

			// CB is already loaded so lets be sure we insert these after CB:
			const stylesheet = document.createElement( 'link' );

			stylesheet.href = cssUrl;
			stylesheet.rel = 'stylesheet';

			stylesheetPosition[0].after( stylesheet );

			$( this ).remove();
		});

		const loadScripts = [];

		headers.children( 'script' ).each( function() {
			const scriptUrl = $( this ).attr( 'src' );

			if ( ! scriptUrl ) {
				loadScripts.push( this );
			} else {
				if ( loadedScripts.indexOf( scriptUrl ) === -1 ) {
					loadScripts.push( this );
				}
			}

			$( this ).remove();
		});

		headers.html( headers.html().trim() );

		return loadScripts;
	}

	function parseScripts( loadScripts ) {
		if ( ! loadScripts.length ) {
			removeEmptyHeaders.call( this );

			return;
		}

		const element = ( this.jquery ? this : $( this ) );
		const scripts = $( '<div class="cbAjaxHeadersScripts hidden" />' );

		const loadScript = function( i ) {
			const nextScript = ( i + 1 );
			const scriptUrl = $( this ).attr( 'src' );

			if ( scriptUrl ) {
				const scriptPosition = $( 'head' ).find( 'script[src*="com_comprofiler"]' ).last();

				if ( ! scriptPosition.length ) {
					// CB isn't loaded so lets just do a temporary usage:
					fetch( scriptUrl, { cache: 'force-cache' } ).then( response => {
						return response.text();
					}).then( () => {
						scripts.append( '<script type="text/javascript" src="' + scriptUrl + '"></script>' );

						if ( typeof loadScripts[nextScript] != 'undefined' ) {
							loadScript.call( loadScripts[nextScript], nextScript );
						}
					});
				} else {
					// CB is already loaded so lets be sure we insert these after CB:
					const script = document.createElement( 'script' );

					script.type = 'text/javascript';
					script.onload = function() {
						if ( typeof loadScripts[nextScript] != 'undefined' ) {
							loadScript.call( loadScripts[nextScript], nextScript );
						}
					};
					script.src = scriptUrl;

					scriptPosition[0].after( script );
				}
			} else {
				scripts.append( '<script type="text/javascript">' + $( this ).text() + '</script>' );

				if ( typeof loadScripts[nextScript] != 'undefined' ) {
					loadScript.call( loadScripts[nextScript], nextScript );
				}
			}
		};

		loadScript.call( loadScripts[0], 0 );

		if ( ! scripts.children( 'script' ).length ) {
			removeEmptyHeaders.call( element );

			return;
		}

		let headers = element.find( '.cbAjaxHeaders' );

		if ( ! headers.length ) {
			headers = element.filter( '.cbAjaxHeaders' );
		}

		headers.append( scripts );
	}

	function rebindScripts() {
		const element = ( this.jquery ? this : $( this ) );

		if ( $.fn.cbtooltip ) {
			element.find( '.cbTooltip,[data-hascbtooltip=\"true\"]' ).cbtooltip();
		}

		if ( $.fn.cbslideImageFile ) {
			element.find( '.cbImageFieldChoice' ).cbslideImageFile();
		}

		if ( $.fn.cbslideVideoFile ) {
			element.find( '.cbVideoFieldChoice' ).cbslideVideoFile();
		}

		if ( $.fn.cbslideAudioFile ) {
			element.find( '.cbAudioFieldChoice' ).cbslideAudioFile();
		}

		if ( $.fn.cbslideFile ) {
			element.find( '.cbFileFieldChoice' ).cbslideFile();
		}

		if ( $.fn.rateit ) {
			element.find( 'div.rateit, span.rateit' ).rateit();
		}
	}

	$.fn.cbajaxfield = function( options ) {
		if ( methods[options] ) {
			return methods[ options ].apply( this, Array.prototype.slice.call( arguments, 1 ) );
		} else if ( ( typeof options === 'object' ) || ( ! options ) ) {
			return methods.init.apply( this, arguments );
		}

		return this;
	};

	$.fn.cbajaxfield.defaults = {
		init: true,
		useData: true,
		mode: 'inline',
		selectors: null,
		ignore: 'a,video,audio,iframe',
		classes: null,
		url: null,
		reason: null,
		post: null
	};
})(jQuery);
<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

use CBLib\Language\CBTxt;

defined( 'CBLIB' ) or die();

/**
 * @var string $formatted
 *
 * @var string $mode
 * @var string $icon
 * @var bool   $inline
 * @var string $editUrl
 */
?>
<div class="cbAjaxLink cbAjaxContainer cbAjaxContainerDisplay<?php echo ( $inline ? ' cbAjaxContainerInline' : '' ); ?> cbClicksInside" data-cbajaxfield-url="<?php echo $editUrl; ?>" data-cbajaxfield-mode="<?php echo $mode; ?>" data-cbajaxfield-classes="cbAjaxLink">
	<div class="cbAjaxValue">
		<?php echo $formatted; ?>
	</div>
	<div class="cbAjaxContainerIcon">
		<a href="javascript: void(0);" class="cbAjaxLink cbAjaxToggle">
			<span class="d-inline-block mr-1 cbAjaxIcon <?php echo ( $icon ?: 'fa fa-pencil' ); ?>"></span>
			<?php echo CBTxt::T( 'AJAX_TOGGLE_EDIT', 'Edit' ); ?>
		</a>
	</div>
</div>
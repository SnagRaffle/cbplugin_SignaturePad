<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

defined( 'CBLIB' ) or die();

/**
 * @var string $formatted
 *
 * @var string $mode
 * @var string $icon
 * @var bool   $inline
 * @var string $editUrl
 */
?>
<div class="cbAjaxCog cbAjaxContainer cbAjaxContainerDisplay<?php echo ( $inline ? ' cbAjaxContainerInline' : '' ); ?> cbClicksInside" data-cbajaxfield-url="<?php echo $editUrl; ?>" data-cbajaxfield-mode="<?php echo $mode; ?>" data-cbajaxfield-classes="cbAjaxCog">
	<div class="cbAjaxValue">
		<?php echo $formatted; ?>
	</div>
	<div class="cbAjaxContainerIcon cbAjaxToggle">
		<span class="cbAjaxIcon <?php echo ( $icon ?: 'fa fa-cog' ); ?>"></span>
	</div>
</div>
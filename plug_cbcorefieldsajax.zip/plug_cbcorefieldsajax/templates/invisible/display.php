<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

use CBLib\Language\CBTxt;

defined( 'CBLIB' ) or die();

/**
 * @var string $formatted
 *
 * @var string $mode
 * @var string $icon
 * @var bool   $inline
 * @var string $editUrl
 */
?>
<div class="cbAjaxInvisible cbAjaxContainer cbAjaxContainerDisplay<?php echo ( $inline ? ' cbAjaxContainerInline' : '' ); ?> cbAjaxContainerToggle cbClicksInside" data-cbajaxfield-url="<?php echo $editUrl; ?>" data-cbajaxfield-mode="<?php echo $mode; ?>" data-cbajaxfield-classes="cbAjaxInvisible">
	<div class="cbAjaxValue">
		<?php echo $formatted; ?>
	</div>
</div>
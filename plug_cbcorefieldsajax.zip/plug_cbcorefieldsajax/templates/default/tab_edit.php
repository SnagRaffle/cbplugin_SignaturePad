<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

use CB\Plugin\Ajax\Helper;
use CBLib\Language\CBTxt;

defined( 'CBLIB' ) or die();

/**
 * @var string $formatted
 *
 * @var int    $mode
 * @var string $saveUrl
 * @var string $csrf
 */
?>
<div class="<?php echo ( $mode === 3 ? 'position-relative popover popover-body ' : null ); ?>cbAjaxDefault cbAjaxContainer cbAjaxContainerTab cbAjaxContainerEdit cb_template cb_template_<?php echo selectTemplate( 'dir' ); ?>">
	<form action="<?php echo $saveUrl; ?>" name="cbAjaxForm" enctype="multipart/form-data" method="post" class="form-auto m-0 cb_form cbAjaxForm cbValidation">
		<div class="cbAjaxButtons">
			<input type="submit" class="btn btn-sm btn-primary cbAjaxSubmit" value="<?php echo htmlspecialchars( CBTxt::T( 'AJAX_UPDATE_BUTTON', 'Update' ) ); ?>" />
			<input type="button" class="btn btn-sm btn-secondary cbAjaxCancel<?php echo ( $mode > 1 ? ' cbTooltipClose' : null ); ?>" value="<?php echo htmlspecialchars( CBTxt::T( 'AJAX_CANCEL_BUTTON', 'Cancel' ) ); ?>" />
		</div>
		<div class="cbAjaxInput">
			<?php echo $formatted; ?>
		</div>
		<?php echo $csrf; ?>
	</form>
	<?php echo Helper::reloadHeaders(); ?>
</div>
<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

use CB\Plugin\Ajax\Helper;
use CBLib\Language\CBTxt;

defined( 'CBLIB' ) or die();

/**
 * @var string $reason
 * @var string $formatted
 *
 * @var int    $mode
 * @var string $format
 * @var string $saveUrl
 * @var string $csrf
 */
?>
<div class="<?php echo ( $mode === 3 ? 'position-relative popover popover-body ' : null ); ?>cbAjaxDefault cbAjaxContainer cbAjaxContainerEdit cb_template cb_template_<?php echo selectTemplate( 'dir' ); ?> cbClicksInside">
	<form action="<?php echo $saveUrl; ?>" name="cbAjaxForm" enctype="multipart/form-data" method="post" class="form-auto m-0 cb_form cbAjaxForm cbValidation">
		<?php if ( $format !== 'none' ) { ?>
		<div class="cbAjaxInput">
			<?php echo $formatted; ?>
		</div>
		<?php } else { ?>
		<div class="form-group cb_form_line clearfix cbAjaxInput">
			<div class="cb_field">
				<?php echo $formatted; ?>
			</div>
		</div>
		<?php } ?>
		<div class="m-0 form-group cb_form_line clearfix cbAjaxButtons">
			<input type="submit" class="btn btn-sm btn-primary cbAjaxSubmit" value="<?php echo htmlspecialchars( CBTxt::T( 'AJAX_UPDATE_BUTTON', 'Update' ) ); ?>" />
			<input type="button" class="btn btn-sm btn-secondary cbAjaxCancel<?php echo ( ( $reason === 'list' ) || ( $mode > 1 ) ? ' cbTooltipClose' : null ); ?>" value="<?php echo htmlspecialchars( CBTxt::T( 'AJAX_CANCEL_BUTTON', 'Cancel' ) ); ?>" />
		</div>
		<?php echo $csrf; ?>
	</form>
	<?php echo Helper::reloadHeaders(); ?>
</div>
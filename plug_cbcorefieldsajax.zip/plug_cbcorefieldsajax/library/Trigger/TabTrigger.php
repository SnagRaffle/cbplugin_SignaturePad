<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

namespace CB\Plugin\Ajax\Trigger;

use CB\Database\Table\TabTable;
use CB\Database\Table\UserTable;
use CB\Plugin\Ajax\Helper;
use CBLib\Application\Application;
use cbPluginHandler;

\defined( 'CBLIB' ) or die();

class TabTrigger extends cbPluginHandler
{
	/**
	 * @param array      $tabsContents
	 * @param TabTable[] $tabsToDisplay
	 * @param UserTable  $user
	 * @param string     $position
	 * @param null|int   $tabId
	 * @return void
	 */
	public function getTabs( &$tabsContents, &$tabsToDisplay, &$user, $position, $tabId )
	{
		global $_CB_framework;

		$excludePositions	=	[ 'canvas_menu', 'canvas_background', 'canvas_photo', 'canvas_info', 'canvas_stats', 'canvas_title' ];

		foreach ( $tabsToDisplay as $k => $tab ) {
			if ( \in_array( $tab->getString( 'position', '' ), $excludePositions, true ) ) {
				continue;
			}

			if ( ! Helper::isOnProfile() ) {
				continue;
			}

			if ( ! Helper::canAjaxEditTab( $tab, $user ) ) {
				continue;
			}

			if ( ! Helper::getFieldsEdit( $tab, $user ) ) {
				continue;
			}

			$editUrl				=	$_CB_framework->pluginClassUrl( 'cbcorefieldsajax', true, [ 'tab' => $tab->getInt( 'tabid', 0 ), 'action' => 'tab.edit', 'user' => $user->getInt( 'id', 0 ), Application::Session()->getFormTokenName() => Application::Session()->getFormTokenValue() ], 'raw' );

			switch ( $tab->params->getInt( 'ajax_profile_output', 1 ) ) {
				case 3:
					$mode			=	'modal';
					break;
				case 2:
					$mode			=	'tooltip';
					break;
				case 1:
				default:
					$mode			=	'inline';
					break;
			}

			$icon					=	$tab->params->getString( 'ajax_icon', '' );

			if ( ! $icon ) {
				$icon				=	Helper::getGlobalParams()->getString( 'general_icon', '' );
			}

			$icon					=	htmlspecialchars( $icon );

			Helper::loadJavaScript();

			ob_start();
			require Helper::getTemplate( $tab->params->getString( 'ajax_template', '' ), 'tab' );
			$html					=	ob_get_clean();

			$tabsContents[$k]		=	$html . $tabsContents[$k];
		}
	}
}
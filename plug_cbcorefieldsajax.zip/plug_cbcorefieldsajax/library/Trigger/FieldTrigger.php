<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

namespace CB\Plugin\Ajax\Trigger;

use CB\Plugin\Ajax\Helper;
use CB\Plugin\FieldGroups\CBFieldGroups;
use CBLib\Input\Get;
use CBLib\Registry\Registry;
use CBLib\Registry\ParamsInterface;
use CB\Database\Table\UserTable;
use CB\Database\Table\FieldTable;
use CBLib\Language\CBTxt;
use CBLib\Application\Application;
use CBLib\Registry\GetterInterface;
use CBuser;
use cbFieldHandler;
use cbValidator;

\defined( 'CBLIB' ) or die();

class FieldTrigger extends cbFieldHandler
{
	/**
	 * Checks if the user can ajax edit the supplied field
	 *
	 * @param FieldTable $field
	 * @param UserTable  $user
	 * @param string     $output
	 * @param string     $reason
	 * @param bool       $ignoreEmpty
	 * @return bool
	 */
	private function canAjaxEdit( &$field, &$user, $output, $reason, $ignoreEmpty = false ): bool
	{
		$exclude			=	[ 'points', 'rating' ];

		if ( Application::Application()->isClient( 'administrator' )
			 || ( $output !== 'html' )
			 || ( ! \in_array( $reason, [ 'profile', 'list' ], true ) )
			 || ( ! $field instanceof FieldTable )
			 || ( ! $user instanceof UserTable )
			 || ( ! $user->getInt( 'id', 0 ) )
			 || ( ! $field->getTableColumns() )
			 || \in_array( $field->getString( 'type', '' ), $exclude, true )
			 || $field->getBool( '_noAjax', false )
		) {
			return false;
		}

		if ( ! $field->params instanceof ParamsInterface ) {
			$field->set( 'params', new Registry( $field->params ) );
		}

		$value				=	$user->get( $field->getString( 'name', '' ) );
		$notEmpty			=	( ( ! ( ( $value === null ) || ( $value === '' ) ) ) || Application::Config()->getInt( 'showEmptyFields', 1 ) || cbReplaceVars( CBTxt::T( $field->params->getString( 'ajax_placeholder', '' ) ), $user ) || ( $field->getString( 'type', '' ) === 'image' ) );
		$readOnly			=	$field->getInt( 'readonly', 0 );

		if ( ( $field->getString( 'name', '' ) === 'username' ) && ( ! Application::Config()->getInt( 'usernameedit', 1 ) ) ) {
			$readOnly		=	true;
		}

		$access				=	cbCheckIfUserCanPerformUserTask( $user->getInt( 'id', 0 ), 'allowModeratorsUserEdit' );

		if ( ( $user->getInt( 'id', 0 ) !== Application::MyUser()->getUserId() ) && ( $access === null ) ) {
			$access			=	checkCBpermissions( [ $user->getInt( 'id', 0 ) ], 'edit', true );
		}

		if ( ( ! $readOnly ) && ( $notEmpty || $ignoreEmpty ) && ( ! $access ) ) {
			if ( ( $reason === 'profile' ) && $field->params->getBool( 'ajax_profile', false ) && Application::MyUser()->canViewAccessLevel( $field->params->getInt( 'ajax_profile_access', 2 ) ) ) {
				return true;
			}

			if ( ( $reason === 'list' ) && $field->params->getBool( 'ajax_list', false ) && Application::MyUser()->canViewAccessLevel( $field->params->getInt( 'ajax_list_access', 2 ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Checks if the user can ajax update the supplied field
	 *
	 * @param FieldTable $field
	 * @param string     $output
	 * @param string     $reason
	 * @param string     $formatting
	 * @return bool
	 */
	private function canAjaxUpdate( &$field, $output, $reason, $formatting = 'div' ): bool
	{
		if ( ! \in_array( $formatting, [ 'div', 'span' ], true ) ) {
			return false;
		}

		if ( $reason === 'profile' ) {
			if ( ( $output !== 'html' )
				 || ( ! $field instanceof FieldTable )
				 || $field->getBool( '_noAjax', false )
			) {
				return false;
			}

			if ( ! $field->params instanceof ParamsInterface ) {
				$field->set( 'params', new Registry( $field->params ) );
			}

			if ( ! $field->params->getString( 'ajax_profile_update', '' ) ) {
				return false;
			}

			return true;
		}

		$exclude			=	[ 'points', 'rating' ];

		if ( ( ! \in_array( $reason, [ 'edit', 'register', 'search' ], true ) )
			 || ( $output !== 'htmledit' )
			 || ( ! $field instanceof FieldTable )
			 || \in_array( $field->getString( 'type', '' ), $exclude, true )
			 || $field->getBool( '_noAjax', false )
		) {
			return false;
		}

		if ( ! $field->params instanceof ParamsInterface ) {
			$field->set( 'params', new Registry( $field->params ) );
		}

		if ( ! $field->params->getString( 'ajax_update', '' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Direct access to field for custom operations, like for Ajax
	 *
	 * WARNING: direct unchecked access, except if $user is set, then check well for the $reason ...
	 *
	 * @param  FieldTable $field
	 * @param  UserTable  $user
	 * @param  array      $postdata
	 * @param  string     $reason 'profile' for user profile view, 'edit' for profile edit, 'register' for registration, 'search' for searches
	 * @return null|string
	 */
	public function getAjaxResponse( &$field, &$user, &$postdata, $reason ): ?string
	{
		global $_CB_framework, $_CB_database, $_PLUGINS;

		switch ( $this->getInput()->getString( 'function', '' ) ) {
			case 'ajax_edit':
				if ( ! $this->canAjaxEdit( $field, $user, 'html', $reason, true ) ) {
					return null;
				}

				$fields									=	cbToArrayOfInt( array_filter( explode( '|*|', $field->params->getString( 'ajax_fields', '' ) ) ) );
				$format									=	( $field->params->getInt( 'fieldVerifyInput', 0 ) || $fields ? 'div' : 'none' );
				$formatted								=	Helper::getFieldsEdit( $field, $user, $format );

				if ( $formatted === '' ) {
					return ' ';
				}

				if ( Application::Application()->isClient( 'administrator' ) ) {
					$saveUrl							=	$_CB_framework->backendViewUrl( 'fieldclass', true, [ 'field' => $field->getString( 'name', '' ), 'function' => 'ajax_save', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason ], 'raw' );
				} else {
					$saveUrl							=	$_CB_framework->viewUrl( 'fieldclass', true, [ 'field' => $field->getString( 'name', '' ), 'function' => 'ajax_save', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason ], 'raw' );
				}

				$mode									=	( $reason === 'list' ? $field->params->getInt( 'ajax_list_output', 2 ) : $field->params->getInt( 'ajax_profile_output', 1 ) );
				$csrf									=	Application::Session()->getFormTokenInput();

				cbValidator::loadValidation();

				ob_start();
				require Helper::getTemplate( $field->params->getString( 'ajax_template', '' ), 'edit' );
				return ob_get_clean();
			case 'ajax_save':
				if ( ! $this->canAjaxEdit( $field, $user, 'html', $reason, true ) ) {
					return null;
				}

				return Helper::saveFieldsEdit( $field, $user, $reason, $postdata );
			case 'ajax_update':
				if ( ! $this->canAjaxUpdate( $field, ( $reason === 'profile' ? 'html' : 'htmledit' ), $reason ) ) {
					return null;
				}

				if ( ! ( $user instanceof UserTable ) ) {
					$user								=	new UserTable();
				}

				if ( $reason === 'profile' ) {
					$field->set( '_isAjaxUpdate', true );
					$field->set( '_noAjax', true );

					$placeholder						=	cbReplaceVars( CBTxt::T( $field->params->getString( 'ajax_placeholder', '' ) ), $user );
					$formatted							=	$_PLUGINS->callField( $field->getString( 'type', '' ), 'getFieldRow', [ &$field, &$user, 'html', 'none', $reason, 0 ], $field );

					if ( ( ( $formatted === null ) || ( trim( $formatted ) === '' ) || ( $formatted === Application::Config()->getString( 'emptyFieldsText', '-' ) ) ) && $placeholder ) {
						$formatted						=	$placeholder;
					}

					$formatted							.=	Helper::reloadHeaders();

					$field->set( '_isAjaxUpdate', false );
					$field->set( '_noAjax', false );

					return $formatted;
				}

				$updateFields							=	$field->params->getString( 'ajax_update', '' );

				if ( ! $updateFields ) {
					return null;
				}

				static $cache							=	[];

				if ( ! isset( $cache[$updateFields] ) ) {
					$query								=	"SELECT " . $_CB_database->NameQuote( 'name' )
														.	"\n FROM " . $_CB_database->NameQuote( '#__comprofiler_fields' )
														.	"\n WHERE " . $_CB_database->NameQuote( 'fieldid' ) . " IN " . $_CB_database->safeArrayOfIntegers( explode( '|*|', $updateFields ) );
					$_CB_database->setQuery( $query );
					$cache[$updateFields]				=	$_CB_database->loadResultArray();
				}

				$allowedFields							=	$cache[$updateFields];

				if ( ! \in_array( $field->getString( 'name', '' ), $allowedFields, true ) ) {
					$allowedFields[]					=	$field->getString( 'name', '' );
				}

				$tempUser								=	clone $user;

				foreach ( $postdata as $k => $v ) {
					if ( ( ! $k ) || ( ! \in_array( $k, $allowedFields, true ) ) ) {
						continue;
					}

					if ( \is_array( $v ) ) {
						$v								=	$this->_implodeCBvalues( $v );
					}

					$tempUser->set( $k, Get::clean( $v, GetterInterface::STRING ) );
				}

				$cbUser									=	CBuser::getInstance( $user->getInt( 'id', 0 ), false );

				$cbUser->_cbuser						=	$tempUser;

				$field->set( '_isAjaxUpdate', true );
				$field->set( '_noAjax', true );
				$field->set( '_noCondition', true );
				$field->set( '_noPrivacy', true );

				$format									=	( $field->params->getInt( 'fieldVerifyInput', 0 ) ? 'div' : 'none' );

				if ( $format !== 'none' ) {
					$return								=	$_PLUGINS->callField( $field->getString( 'type', '' ), 'getFieldRow', [ &$field, &$tempUser, 'htmledit', $format, $reason, 0 ], $field );
				} else {
					$return								=	$_PLUGINS->callField( $field->getString( 'type', '' ), 'getFieldRow', [ &$field, &$tempUser, 'htmledit', 'none', $reason, 0 ], $field );
				}

				$cbUser->_cbuser						=	$user;

				$field->set( '_isAjaxUpdate', false );
				$field->set( '_noAjax', false );
				$field->set( '_noCondition', false );
				$field->set( '_noPrivacy', false );

				if ( ( $return === null ) || ( trim( $return ) === '' ) || ( $field->getBool( '_isAjaxUpdateEmpty', false ) && ( ! $field->params->getBool( 'ajax_update_empty', true ) ) ) ) {
					return ' ';
				}

				return $return . Helper::reloadHeaders();
		}

		return null;
	}

	/**
	 * Formatter:
	 * Returns a field in specified format
	 *
	 * @param  FieldTable  $field
	 * @param  UserTable   $user
	 * @param  string      $output               'html', 'xml', 'json', 'php', 'csvheader', 'csv', 'rss', 'fieldslist', 'htmledit'
	 * @param  string      $formatting           'tr', 'td', 'div', 'span', 'none',   'table'??
	 * @param  string      $reason               'profile' for user profile view, 'edit' for profile edit, 'register' for registration, 'search' for searches
	 * @param  int         $list_compare_types   IF reason == 'search' : 0 : simple 'is' search, 1 : advanced search with modes, 2 : simple 'any' search
	 * @return mixed
	 */
	public function getAjaxDisplay( &$field, &$user, $output, $formatting, $reason, $list_compare_types )
	{
		global $_CB_framework, $_PLUGINS, $_CB_fieldIconDisplayed;

		$canAjaxUpdate				=	$this->canAjaxUpdate( $field, $output, $reason, $formatting );
		$canAjaxEdit				=	$this->canAjaxEdit( $field, $user, $output, $reason );

		if ( ( ! $canAjaxUpdate ) && ( ! $canAjaxEdit ) ) {
			return null;
		}

		$fieldId					=	$field->getInt( 'fieldid', 0 );

		if ( $canAjaxUpdate ) {
			if ( $reason === 'search' ) {
				$selectorPrefix		=	'.cbUserListSearchFields ';
			} else {
				$selectorPrefix		=	'';
			}

			if ( $reason === 'profile' ) {
				$selectorSuffix		=	' .cbAjaxContainerDisplay';
			} else {
				$selectorSuffix		=	'';
			}

			$updateOn				=	cbToArrayOfInt( array_filter( explode( '|*|', ( $reason === 'profile' ? $field->params->getString( 'ajax_profile_update', '' ) : $field->params->getString( 'ajax_update', '' ) ) ) ) );
			$selectors				=	[];

			foreach ( $updateOn as $updateField ) {
				$selectors[]		=	$selectorPrefix . '#cbfr_' . (int) $updateField . $selectorSuffix;

				if ( $field->getBool( '_isGrouped', false ) ) {
					$selectors[]	=	$selectorPrefix . '.cbRepeatRow #cbfr_' . (int) $updateField . $selectorSuffix;
				}
			}

			if ( $selectors ) {
				if ( Application::Application()->isClient( 'administrator' ) ) {
					$updateUrl		=	$_CB_framework->backendViewUrl( 'fieldclass', false, [ 'field' => $field->getString( 'name', '' ), 'function' => 'ajax_update', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason, Application::Session()->getFormTokenName() => Application::Session()->getFormTokenValue() ], 'raw' );
				} else {
					$updateUrl		=	$_CB_framework->viewUrl( 'fieldclass', false, [ 'field' => $field->getString( 'name', '' ), 'function' => 'ajax_update', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason, Application::Session()->getFormTokenName() => Application::Session()->getFormTokenValue() ], 'raw' );
				}

				$jsTargets					=	[];
				$jsTargets[]				=	$selectorPrefix . '#cbfr_' . $fieldId;

				if ( $field->getBool( '_isGrouped', false ) ) {
					$jsTargets[]			=	$selectorPrefix . '.cbRepeatRow #cbfr_' . $fieldId;
				}

				$_CB_framework->addJQueryPlugin( 'cbajaxfield', '/components/com_comprofiler/plugin/user/plug_cbcorefieldsajax/js/jquery.cbcorefieldsajax.js' );

				$js					=	"$( " . json_encode( implode( ',', $jsTargets ), JSON_HEX_TAG ) . " ).cbajaxfield({"
									.		"mode: 'update',"
									.		"reason: " . json_encode( $reason, JSON_HEX_TAG ) . ","
									.		"selectors: " . json_encode( implode( ',', $selectors ), JSON_HEX_TAG ) . ","
									.		"url: " . json_encode( $updateUrl, JSON_HEX_TAG )
									.	"});";

				$_CB_framework->outputCbJQuery( $js, 'cbajaxfield' );
			}
		}

		if ( $canAjaxEdit ) {
			if ( ( $reason === 'profile' ) && $field->params->getBool( 'ajax_profile_strict', false ) && ( ! Helper::isOnProfile() ) ) {
				return null;
			}

			if ( ( $reason === 'list' ) && $field->params->getBool( 'ajax_list_strict', false ) && ( ! $field->getBool( '_ajaxOnList', false ) ) ) {
				return null;
			}

			$field->set( '_noAjax', true );

			$iconsRendered			=	isset( $_CB_fieldIconDisplayed[$fieldId] );

			ob_start();
			$hasEdit				=	$_PLUGINS->callField( $field->getString( 'type', '' ), 'getFieldRow', [ &$field, &$user, 'htmledit', 'none', 'edit', $list_compare_types ], $field );
			ob_end_clean();

			if ( ( ! $iconsRendered ) && isset( $_CB_fieldIconDisplayed[$fieldId] ) ) {
				unset( $_CB_fieldIconDisplayed[$fieldId] );
			}

			if ( ( $hasEdit === null ) || trim( $hasEdit ) === '' ) {
				$field->set( '_noAjax', false );

				return null;
			}

			$placeholder			=	cbReplaceVars( CBTxt::T( $field->params->getString( 'ajax_placeholder', '' ) ), $user );
			$formatted				=	$_PLUGINS->callField( $field->getString( 'type', '' ), 'getFieldRow', [ &$field, &$user, $output, 'none', $reason, $list_compare_types ], $field );

			if ( ( ( $formatted === null ) || ( trim( $formatted ) === '' ) || ( $formatted === Application::Config()->getString( 'emptyFieldsText', '-' ) ) ) && $placeholder ) {
				$formatted			=	$placeholder;
			}

			if ( ( $formatted === null ) || trim( $formatted ) === '' ) {
				$field->set( '_noAjax', false );

				return null;
			}

			if ( Application::Application()->isClient( 'administrator' ) ) {
				$editUrl			=	$_CB_framework->backendViewUrl( 'fieldclass', true, [ 'field' => $field->getString( 'name', '' ), 'function' => 'ajax_edit', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason, Application::Session()->getFormTokenName() => Application::Session()->getFormTokenValue() ], 'raw' );
			} else {
				$editUrl			=	$_CB_framework->viewUrl( 'fieldclass', true, [ 'field' => $field->getString( 'name', '' ), 'function' => 'ajax_edit', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason, Application::Session()->getFormTokenName() => Application::Session()->getFormTokenValue() ], 'raw' );
			}

			switch ( ( $reason === 'list' ? $field->params->getInt( 'ajax_list_output', 2 ) : $field->params->getInt( 'ajax_profile_output', 1 ) ) ) {
				case 3:
					$mode			=	'modal';
					break;
				case 2:
					$mode			=	'tooltip';
					break;
				case 1:
				default:
					$mode			=	( $reason === 'list' ? 'tooltip' : 'inline' );
					break;
			}

			$inline					=	\in_array( $formatting, [ 'span', 'none' ], true );
			$icon					=	$field->params->getString( 'ajax_icon', '' );

			if ( ! $icon ) {
				$icon				=	Helper::getGlobalParams()->getString( 'general_icon', '' );
			}

			$icon					=	htmlspecialchars( $icon );

			Helper::loadJavaScript();

			ob_start();
			require Helper::getTemplate( $field->params->getString( 'ajax_template', '' ), 'display' );
			$html					=	ob_get_clean();

			$return					=	$this->renderFieldHtml( $field, $user, $html, $output, $formatting, $reason, [] );

			$field->set( '_noAjax', false );

			return $return;
		}

		return null;
	}
}
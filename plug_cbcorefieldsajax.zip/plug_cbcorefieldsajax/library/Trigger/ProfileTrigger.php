<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

namespace CB\Plugin\Ajax\Trigger;

use CB\Plugin\Ajax\Helper;
use cbPluginHandler;

\defined( 'CBLIB' ) or die();

class ProfileTrigger extends cbPluginHandler
{
	/**
	 * @return void
	 */
	public function onProfileStart(): void
	{
		Helper::setIsOnProfile( true );
	}

	/**
	 * @return void
	 */
	public function onProfileEnd(): void
	{
		Helper::setIsOnProfile( false );
	}
}
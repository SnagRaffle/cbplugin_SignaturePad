<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

namespace CB\Plugin\Ajax;

use CB\Database\Table\FieldTable;
use CB\Database\Table\TabTable;
use CB\Database\Table\UserTable;
use CB\Plugin\Ajax\Trigger\FieldTrigger;
use CBLib\Language\CBTxt;
use CBLib\Registry\ParamsInterface;
use CBLib\Registry\Registry;
use CBLib\Application\Application;
use cbTabs;
use CBuser;
use cbValidator;

\defined( 'CBLIB' ) or die();

class Helper
{
	/** @var bool  */
	private static bool $canTabAjax		=	true;
	/** @var bool  */
	private static bool $isOnProfile	=	false;

	/**
	 * @return Registry
	 */
	public static function getGlobalParams(): Registry
	{
		global $_PLUGINS;

		static $params	=	null;

		if ( ! $params ) {
			$plugin		=	$_PLUGINS->getLoadedPlugin( 'user', 'cbcorefieldsajax' );
			$params		=	new Registry();

			if ( $plugin ) {
				$params->load( $plugin->params );
			}
		}

		return $params;
	}

	/**
	 * @param null|string $template
	 * @param null|string $file
	 * @param bool|array  $headers
	 * @return null|string
	 */
	public static function getTemplate( ?string $template = null, ?string $file = null, $headers = [ 'template', 'override' ] ): ?string
	{
		global $_CB_framework, $_PLUGINS;

		$plugin							=	$_PLUGINS->getLoadedPlugin( 'user', 'cbcorefieldsajax' );

		if ( ! $plugin ) {
			return null;
		}

		static $defaultTemplate			=	null;

		if ( $defaultTemplate === null ) {
			$defaultTemplate			=	self::getGlobalParams()->getString( 'general_template', 'default' );
		}

		if ( ( $template === '' ) || ( $template === null ) || ( $template === '-1' ) ) {
			$template					=	$defaultTemplate;
		}

		if ( ! $template ) {
			$template					=	'default';
		}

		$livePath						=	$_PLUGINS->getPluginLivePath( $plugin );
		$absPath						=	$_PLUGINS->getPluginPath( $plugin );

		if ( $headers !== false ) {
			static $loaded				=	[];

			$loaded[$template]			=	[];

			// Global CSS File:
			if ( \in_array( 'template', $headers, true ) && ( ! \in_array( 'template', $loaded[$template], true ) ) ) {
				$global					=	'/templates/' . $template . '/template.css';

				if ( ! file_exists( $absPath . $global ) ) {
					$global				=	'/templates/default/template.css';
				}

				if ( file_exists( $absPath . $global ) ) {
					$_CB_framework->document->addHeadStyleSheet( $livePath . $global, true );
				}

				$loaded[$template][]	=	'template';
			}

			// File or Custom CSS/JS Headers:
			foreach ( $headers as $header ) {
				if ( \in_array( $header, $loaded[$template], true ) || \in_array( $header, [ 'template', 'override' ], true ) ) {
					continue;
				}

				$header					=	preg_replace( '/[^-a-zA-Z0-9_]/', '', $header );

				if ( ! $header ) {
					continue;
				}

				$css					=	'/templates/' . $template . '/' . $header . '.css';
				$js						=	'/templates/' . $template . '/' . $header . '.js';

				if ( ! file_exists( $absPath . $css ) ) {
					$css				=	'/templates/default/' . $header . '.css';
				}

				if ( file_exists( $absPath . $css ) ) {
					$_CB_framework->document->addHeadStyleSheet( $livePath . $css, true );
				}

				if ( ! file_exists( $absPath . $js ) ) {
					$js					=	'/templates/default/' . $header . '.js';
				}

				if ( file_exists( $absPath . $js ) ) {
					$_CB_framework->document->addHeadScriptUrl( $livePath . $js );
				}

				$loaded[$template][]	=	$header;
			}

			// Override CSS File:
			if ( \in_array( 'override', $headers, true ) && ( ! \in_array( 'override', $loaded[$template], true ) ) ) {
				$override				=	'/templates/' . $template . '/override.css';

				if ( file_exists( $absPath . $override ) ) {
					$_CB_framework->document->addHeadStyleSheet( $livePath . $override, true );
				}

				$loaded[$template][]	=	'override';
			}
		}

		$file							=	preg_replace( '/[^-a-zA-Z0-9_]/', '', $file );
		$return							=	null;

		if ( $file ) {
			$php						=	$absPath . '/templates/' . $template . '/' . $file . '.php';

			if ( ! file_exists( $php ) ) {
				$php					=	$absPath . '/templates/default/' . $file . '.php';
			}

			if ( file_exists( $php ) ) {
				$return					=	$php;
			}
		}

		return $return;
	}

	/**
	 * Reloads and outputs the JS headers for ajax output
	 *
	 * @return string
	 */
	public static function reloadHeaders(): string
	{
		global $_CB_framework;

		if ( Application::Input()->getString( 'format' ) !== 'raw' ) {
			return '';
		}

		$_CB_framework->getAllJsPageCodes();

		// Reset meta headers as they can't be used inline anyway:
		$_CB_framework->document->_head['metaTags']		=	[];

		// Reset custom headers as we can't guarantee they can output inline:
		$_CB_framework->document->_head['custom']		=	[];

		// Remove all non-jQuery scripts as they'll likely just cause errors due to redeclaration:
		foreach( $_CB_framework->document->_head['scriptsUrl'] as $url => $script ) {
			if ( ( strpos( $url, 'jquery.' ) === false ) || ( strpos( $url, 'migrate' ) !== false ) ) {
				unset( $_CB_framework->document->_head['scriptsUrl'][$url] );
			}
		}

		$header				=	trim( $_CB_framework->document->outputToHead() );

		if ( ! $header ) {
			return '';
		}

		$return				=	'<div class="cbAjaxHeaders hidden">';

		if ( ( strpos( $header, 'cbjQuery' ) !== false ) && ( strpos( $header, 'window.$ = cbjQuery;' ) === false ) ) {
			// The jQuery pointer is missing so lets add it so jQuery rebinds correctly:
			$return			.=		'<script type="text/javascript">window.$ = cbjQuery; window.jQuery = cbjQuery;</script>';
		}

		$return				.=		$header
							.	'</div>';

		return $return;
	}

	/**
	 * @return void
	 */
	public static function loadJavaScript(): void
	{
		global $_CB_framework;

		static $loaded			=	0;

		if ( ! $loaded++ ) {
			cbValidator::loadValidation();
			initToolTip();

			$_CB_framework->addJQueryPlugin( 'cbajaxfield', '/components/com_comprofiler/plugin/user/plug_cbcorefieldsajax/js/jquery.cbcorefieldsajax.js' );

			$js						=	"$( '.cb_tab_overlib_container,.cb_tab_overlib_fix_container,.cb_tab_overlib_sticky_container' ).on( 'cbtooltip.render', function( e, cbtooltip, event, api ) {"
									.		"$( api.elements.content ).find( '.cbAjaxContainerDisplay' ).cbajaxfield();"
									.	"});"
									.	"$( '.cbAjaxContainerDisplay' ).cbajaxfield();";

			$_CB_framework->outputCbJQuery( $js, [ 'cbajaxfield', 'form' ] );
		}
	}

	/**
	 * @param TabTable|FieldTable $object
	 * @param UserTable           $user
	 * @param string              $format
	 * @return void
	 */
	public static function getFieldsEdit( $object, UserTable $user, string $format = 'div' ): string
	{
		global $_PLUGINS;

		$fields							=	cbToArrayOfInt( array_filter( explode( '|*|', $object->params->getString( 'ajax_fields', '' ) ) ) );
		$fieldsTitles					=	( $fields ? $object->params->getString( 'ajax_fields_titles', '' ) : '' );

		if ( $fields ) {
			if ( $object instanceof FieldTable ) {
				$fields[]				=	$object->getInt( 'fieldid', 0 );
				$availableFields		=	CBuser::getInstance( $user->getInt( 'id', 0 ), false )->_getCbTabs( false )->_getTabFieldsDb( 0, $user, 'edit' );
			} else {
				$availableFields		=	CBuser::getInstance( $user->getInt( 'id', 0 ), false )->_getCbTabs( false )->_getTabFieldsDb( $object->getInt( 'tabid', 0 ), $user, 'edit' );
			}
		} elseif ( $object instanceof FieldTable ) {
			$fields						=	[ $object->getInt( 'fieldid', 0 ) ];
			$availableFields			=	[ $object ];
		} else {
			$availableFields			=	CBuser::getInstance( $user->getInt( 'id', 0 ), false )->_getCbTabs( false )->_getTabFieldsDb( $object->getInt( 'tabid', 0 ), $user, 'edit' );
			$fields						=	cbToArrayOfInt( array_keys( $availableFields ) );
		}

		$formatted						=	'';

		foreach ( $availableFields as $editField ) {
			if ( ! \in_array( $editField->getInt( 'fieldid', 0 ), $fields, true ) ) {
				continue;
			}

			$editField->set( '_noAjax', true );

			$previousTitlesDisplay		=	$editField->getInt( 'edit', 0 );

			if ( $fieldsTitles !== '' ) {
				$editField->set( 'edit', (int) $fieldsTitles );
			}

			ob_start();
			if ( $format !== 'none' ) {
				$formatted				.=	$_PLUGINS->callField( $editField->getString( 'type', '' ), 'getFieldRow', [ &$editField, &$user, 'htmledit', $format, 'edit', 0 ], $editField );
			} else {
				$formatted				.=	$_PLUGINS->callField( $editField->getString( 'type', '' ), 'getFieldRow', [ &$editField, &$user, 'htmledit', 'none', 'edit', 0 ], $editField );
			}
			$formatted					.=	ob_get_clean();

			if ( $fieldsTitles !== '' ) {
				$editField->set( 'edit', $previousTitlesDisplay );
			}

			$editField->set( '_noAjax', false );
		}

		return trim( $formatted );
	}

	/**
	 * @param TabTable|FieldTable $object
	 * @param UserTable           $user
	 * @param string              $reason
	 * @param null|array          $postdata
	 * @return string
	 */
	public static function saveFieldsEdit( $object, UserTable $user, string $reason = 'profile', ?array $postdata = null ): string
	{
		global $_CB_framework, $_PLUGINS;

		if ( $postdata === null ) {
			$postdata							=	Application::Input()->getNamespaceRegistry( 'post' )->asArray();
		}

		$fields									=	cbToArrayOfInt( array_filter( explode( '|*|', $object->params->getString( 'ajax_fields', '' ) ) ) );
		/** @var FieldTable[] $editFields */
		$editFields								=	[];

		if ( $fields ) {
			if ( $object instanceof FieldTable ) {
				$fields[]						=	$object->getInt( 'fieldid', 0 );
				$availableFields				=	CBuser::getInstance( $user->getInt( 'id', 0 ), false )->_getCbTabs( false )->_getTabFieldsDb( 0, $user, 'edit' );
			} else {
				$availableFields				=	CBuser::getInstance( $user->getInt( 'id', 0 ), false )->_getCbTabs( false )->_getTabFieldsDb( $object->getInt( 'tabid', 0 ), $user, 'edit' );
			}

			foreach ( $availableFields as $availableField ) {
				if ( ! \in_array( $availableField->getInt( 'fieldid', 0 ), $fields, true ) ) {
					continue;
				}

				$editFields[]					=	$availableField;
			}
		} elseif ( $object instanceof FieldTable ) {
			$editFields[]						=	$object;
		} else {
			$editFields							=	CBuser::getInstance( $user->getInt( 'id', 0 ), false )->_getCbTabs( false )->_getTabFieldsDb( $object->getInt( 'tabid', 0 ), $user, 'edit' );
		}

		foreach ( $editFields as $editField ) {
			$editField->set( '_noAjax', true );

			if ( \in_array( $editField->getString( 'name', '' ), [ 'firstname', 'middlename', 'lastname' ], true ) ) {
				if ( $editField->getString( 'name', '' ) !== 'firstname' ) {
					$postdata['firstname']		=	$user->getString( 'firstname' );
				}

				if ( $editField->getString( 'name', '' ) !== 'middlename' ) {
					$postdata['middlename']		=	$user->getString( 'middlename' );
				}

				if ( $editField->getString( 'name', '' ) !== 'lastname' ) {
					$postdata['lastname']		=	$user->getString( 'lastname' );
				}
			}

			$_PLUGINS->callField( $editField->getString( 'type', '' ), 'fieldClass', [ &$editField, &$user, &$postdata, 'edit' ], $editField );

			$editField->set( '_noAjax', false );
		}

		$oldUserComplete						=	clone $user;
		$orgValues								=	[];

		foreach ( $editFields as $editField ) {
			$editField->set( '_noAjax', true );

			$fieldName							=	$editField->getString( 'name', '' );
			$orgValues[$fieldName]				=	$user->get( $fieldName );

			$_PLUGINS->callField( $editField->getString( 'type', '' ), 'prepareFieldDataSave', [ &$editField, &$user, &$postdata, 'edit' ], $editField );

			$editField->set( '_noAjax', false );
		}

		$store									=	false;

		if ( ! \count( $_PLUGINS->getErrorMSG( false ) ) ) {
			foreach ( $editFields as $editField ) {
				$editField->set( '_noAjax', true );

				$_PLUGINS->callField( $editField->getString( 'type', '' ), 'commitFieldDataSave', [ &$editField, &$user, &$postdata, 'edit' ], $editField );

				$editField->set( '_noAjax', false );
			}

			if ( ! \count( $_PLUGINS->getErrorMSG( false ) ) ) {
				if ( Application::MyUser()->getUserId() === $user->getInt( 'id', 0 ) ) {
					$user->set( 'lastupdatedate', Application::Database()->getUtcDateTime() );
				}

				$_PLUGINS->trigger( 'onBeforeUserUpdate', [ &$user, &$user, &$oldUserComplete, &$oldUserComplete ] );

				$clearTextPassword				=	null;

				foreach ( $editFields as $editField ) {
					if ( $editField->getString( 'name', '' ) === 'password' ) {
						$clearTextPassword		=	$user->getString( 'password' );

						$user->set( 'password', $user->hashAndSaltPassword( $clearTextPassword ) );
					}
				}

				$store							=	$user->store();

				if ( $clearTextPassword ) {
					$user->set( 'password', $clearTextPassword );
				}

				$_PLUGINS->trigger( 'onAfterUserUpdate', [ &$user, &$user, $oldUserComplete ] );
			} else {
				foreach ( $editFields as $editField ) {
					$editField->set( '_noAjax', true );

					$_PLUGINS->callField( $editField->getString( 'type', '' ), 'rollbackFieldDataSave', [ &$editField, &$user, &$postdata, 'edit' ], $editField );

					$editField->set( '_noAjax', false );
				}

				$_PLUGINS->trigger( 'onSaveUserError', [ &$user, $user->getError(), 'edit' ] );
			}
		}

		if ( ! $store ) {
			foreach ( $orgValues as $fieldName => $orgValue ) {
				if ( $orgValue !== $user->get( $fieldName ) ) {
					$user->set( $fieldName, $orgValue );
				}
			}
		}

		$errors									=	null;

		foreach ( $editFields as $editField ) {
			$error								=	self::getFieldsEditError( $editField, $user );

			if ( $error ) {
				$errors							.=	'<div class="p-2 alert alert-danger cbAjaxError">' . $error . '</div>';
			}
		}

		if ( $errors ) {
			return $errors;
		}

		if ( $object instanceof FieldTable ) {
			$cbUser								=	CBuser::getInstance( $user->getInt( 'id', 0 ), false );
			$placeholder						=	$cbUser->replaceUserVars( CBTxt::T( $object->params->getString( 'ajax_placeholder', '' ) ) );
			$emptyValue							=	$cbUser->replaceUserVars( Application::Config()->getString( 'emptyFieldsText', '-' ) );

			$object->set( '_noAjax', true );

			if ( $reason === 'profile' ) {
				$_CB_framework->setDisplayedUser( $user->getInt( 'id', 0 ) );

				if ( $object->params->getBool( 'ajax_profile_strict', false ) ) {
					self::$isOnProfile			=	true;
				}
			}

			if ( ( $reason === 'list' ) && $object->params->getBool( 'ajax_list_strict', false ) ) {
				$object->set( '_ajaxOnList', true );
			}

			$return								=	$_PLUGINS->callField( $object->getString( 'type', '' ), 'getFieldRow', [ &$object, &$user, 'html', 'none', $reason, 0 ], $object );

			$object->set( '_noAjax', false );

			if ( ( $reason === 'profile' ) && $object->params->getBool( 'ajax_profile_strict', false ) ) {
				self::$isOnProfile				=	false;
			}

			if ( ( $reason === 'list' ) && $object->params->getBool( 'ajax_list_strict', false ) ) {
				$object->set( '_ajaxOnList', false );
			}

			if ( ( ( $return === null ) || ( trim( $return ) === '' ) || ( $return === $emptyValue ) ) && $placeholder ) {
				$return							=	$placeholder;
			} elseif ( ( ( $return === null ) || ( trim( $return ) === '' ) ) && ( ! Application::Config()->getInt( 'showEmptyFields', 1 ) ) ) {
				$return							=	$emptyValue;
			}

			$return								.=	self::reloadHeaders();

			return $return;
		}

		$_CB_framework->setDisplayedUser( $user->getInt( 'id', 0 ) );

		$object->set( '_noAjax', true );

		self::$canTabAjax						=	false;
		self::$isOnProfile						=	true;

		$cbTabs									=	new cbTabs( 0, 1, null, false );

		$cbTabs->generateViewTabsContent( $user, $object->getString( 'position', '' ), $object->getInt( 'tabid', 0 ) );

		$return									=	$cbTabs->getProfileTabHtml( $object->getInt( 'tabid', 0 ) )
												.	self::reloadHeaders();

		$object->set( '_noAjax', false );

		self::$canTabAjax						=	true;
		self::$isOnProfile						=	false;

		return $return;
	}

	/**
	 * Parse field validation errors into user readable
	 *
	 * @param FieldTable $field
	 * @param UserTable  $user
	 * @return string
	 */
	private static function getFieldsEditError( FieldTable $field, UserTable $user ): string
	{
		global $_PLUGINS;

		$errors		=	$_PLUGINS->getErrorMSG( false );

		if ( $errors ) {
			$title	=	$_PLUGINS->callField( $field->getString( 'type', '' ), 'getFieldTitle', [ &$field, &$user, 'text', 'edit' ], $field );

			foreach ( $errors as $error ) {
				if ( stripos( $error, $title ) !== false ) {
					return str_replace( $title . ' : ', '', $error );
				}
			}
		}

		return '';
	}

	/**
	 * Checks if the user can ajax edit the supplied tab
	 *
	 * @param TabTable  $tab
	 * @param UserTable $user
	 * @return bool
	 */
	public static function canAjaxEditTab( &$tab, &$user ): bool
	{
		if ( Application::Application()->isClient( 'administrator' )
			 || ( ! $tab instanceof TabTable )
			 || ( ! $user instanceof UserTable )
			 || ( ! $user->getInt( 'id', 0 ) )
			 || ( ! $tab->getBool( 'fields', true ) )
			 || $tab->getBool( '_noAjax', false )
			 || ( ! self::$canTabAjax )
		) {
			return false;
		}

		if ( ! $tab->params instanceof ParamsInterface ) {
			$tab->set( 'params', new Registry( $tab->params ) );
		}

		$access				=	cbCheckIfUserCanPerformUserTask( $user->getInt( 'id', 0 ), 'allowModeratorsUserEdit' );

		if ( ( $user->getInt( 'id', 0 ) !== Application::MyUser()->getUserId() ) && ( $access === null ) ) {
			$access			=	checkCBpermissions( [ $user->getInt( 'id', 0 ) ], 'edit', true );
		}

		return ( ( ! $access ) && $tab->params->getBool( 'ajax_profile', false ) && Application::MyUser()->canViewAccessLevel( $tab->params->getInt( 'ajax_profile_access', 2 ) ) );
	}

	/**
	 * @return bool
	 */
	public static function isOnProfile(): bool
	{
		return self::$isOnProfile;
	}

	/**
	 * @param bool $isOnProfile
	 * @return void
	 */
	public static function setIsOnProfile( bool $isOnProfile ): void
	{
		self::$isOnProfile	=	$isOnProfile;
	}
}
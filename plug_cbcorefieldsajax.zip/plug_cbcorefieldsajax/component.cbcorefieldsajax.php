<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

use CB\Database\Table\TabTable;
use CB\Database\Table\UserTable;
use CB\Plugin\Ajax\Helper;
use CBLib\Application\Application;

if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

global $_PLUGINS;

$_PLUGINS->loadPluginGroup( 'user' );

class CBplug_cbcorefieldsajax extends cbPluginHandler
{
	/**
	 * @param null|TabTable  $tab
	 * @param null|UserTable $user
	 * @param null|int       $ui
	 * @param null|array     $postdata
	 */
	public function getCBpluginComponent( ?TabTable $tab, ?UserTable $user, ?int $ui, ?array $postdata ): void
	{
		if ( ! Application::Session()->checkFormToken( 'request' ) ) {
			header( 'HTTP/1.0 401 Unauthorized' );
			exit();
		}

		$tabId						=	Application::Input()->getInt( 'tab', 0 );

		if ( ! $tabId ) {
			header( 'HTTP/1.0 401 Unauthorized' );
			exit();
		}

		if ( $tab === null ) {
			$tab					=	new TabTable();

			$tab->load( $tabId );
		}

		if ( ! $tab->getInt( 'tabid', 0 ) ) {
			header( 'HTTP/1.0 401 Unauthorized' );
			exit();
		}

		$userId						=	Application::Input()->getInt( 'user', 0 );

		if ( ! $userId ) {
			header( 'HTTP/1.0 401 Unauthorized' );
			exit();
		}

		if ( $user === null ) {
			$user					=	CBuser::getUserDataInstance( $userId );
		}

		if ( ! Helper::canAjaxEditTab( $tab, $user ) ) {
			header( 'HTTP/1.0 401 Unauthorized' );
			exit();
		}

		[ $action, $function ]		=	explode( '.', $this->getInput()->getString( 'action', '' ), 2 );

		switch ( $action ) {
			case 'tab':
				switch ( $function ) {
					case 'save':
						$this->saveTabEdit( $tab, $user );
						break;
					case 'edit':
					default:
						$this->displayTabEdit( $tab, $user );
						break;
				}
				break;
			default:
				header( 'HTTP/1.0 401 Unauthorized' );
				exit();
		}
	}

	/**
	 * @param TabTable  $tab
	 * @param UserTable $user
	 * @return void
	 */
	private function displayTabEdit( TabTable $tab, UserTable $user ): void
	{
		global $_CB_framework;

		$saveUrl	=	$_CB_framework->pluginClassUrl( 'cbcorefieldsajax', true, [ 'tab' => $tab->getInt( 'tabid', 0 ), 'action' => 'tab.save', 'user' => $user->getInt( 'id', 0 ) ], 'raw' );
		$mode		=	$tab->params->getInt( 'ajax_profile_output', 1 );
		$csrf		=	Application::Session()->getFormTokenInput();

		cbValidator::loadValidation();

		$formatted	=	Helper::getFieldsEdit( $tab, $user );

		require Helper::getTemplate( $tab->params->getString( 'ajax_template', '' ), 'tab_edit' );
	}

	/**
	 * @param TabTable  $tab
	 * @param UserTable $user
	 * @return void
	 */
	private function saveTabEdit( TabTable $tab, UserTable $user ): void
	{
		echo Helper::saveFieldsEdit( $tab, $user );
	}
}
<?php
/**
* Community Builder (TM) cbcorefieldsajax Default (English) language file Administration
* @version $Id:$
* @copyright (C) 2004-2024 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

/**
* WARNING:
* Do not make changes to this file as it will be over-written when you upgrade CB.
* To localize you need to create your own CB language plugin and make changes there.
*/

defined('CBLIB') or die();

return	array(
// 4 language strings from file plug_cbcorefieldsajax/cbcorefieldsajax.xml
'FIELD_AJAX_PREFERENCES_429503'	=>	'Field ajax preferences',
'PROFILE_VIEW_307f0e'	=>	'Profile View',
'PROFILE_EDIT_REGISTRATION_4de2a2'	=>	'Profile Edit / Registration',
'USERLIST_VIEW_63dd06'	=>	'Userlist View',
);

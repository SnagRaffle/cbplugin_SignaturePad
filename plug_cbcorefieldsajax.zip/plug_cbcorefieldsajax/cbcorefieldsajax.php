<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

use CB\Plugin\Ajax\Trigger\FieldTrigger;
use CB\Plugin\Ajax\Trigger\ListTrigger;
use CB\Plugin\Ajax\Trigger\ProfileTrigger;
use CB\Plugin\Ajax\Trigger\TabTrigger;
use CBLib\Core\AutoLoader;

defined( 'CBLIB' ) or die();

global $_CB_framework, $_PLUGINS;

AutoLoader::registerExactMap( '%^CB/Plugin/Ajax/(.+)%i', __DIR__ . '/library/$1.php' );

$_PLUGINS->loadPluginGroup( 'user' );

$_PLUGINS->registerFunction( 'onBeforeUserProfileRequest', 'onProfileStart', ProfileTrigger::class );
$_PLUGINS->registerFunction( 'onAfterUserProfileDisplay', 'onProfileEnd', ProfileTrigger::class );

$_PLUGINS->registerFunction( 'onAfterUsersListFieldsSql', 'checkListStrict', ListTrigger::class );

$_PLUGINS->registerUserFieldParams();
$_PLUGINS->registerFunction( 'onBeforefieldClass', 'getAjaxResponse', FieldTrigger::class );
$_PLUGINS->registerFunction( 'onBeforegetFieldRow', 'getAjaxDisplay', FieldTrigger::class );

$_PLUGINS->registerFunction( 'onAfterPrepareViewTabs', 'getTabs', TabTrigger::class );
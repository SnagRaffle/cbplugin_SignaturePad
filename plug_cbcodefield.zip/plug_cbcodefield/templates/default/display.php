<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

use CB\Database\Table\UserTable;
use CB\Database\Table\FieldTable;
use CB\Plugin\Code\CBCodeField;

defined( 'CBLIB' ) or die();

/**
 * @var string     $code
 * @var FieldTable $field
 * @var UserTable  $user
 * @var string     $reason
 */

echo CBCodeField::outputCode( $code, $field, $user, $reason );
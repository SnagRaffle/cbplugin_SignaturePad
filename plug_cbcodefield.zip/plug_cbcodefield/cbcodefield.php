<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

use CB\Plugin\Code\Trigger\FieldTrigger;
use CB\Plugin\Code\Field\CodeField;
use CB\Plugin\Code\Field\CodeSelectField;
use CBLib\Core\AutoLoader;

defined( 'CBLIB' ) or die();

global $_CB_framework, $_PLUGINS;

AutoLoader::registerExactMap( '%^CB/Plugin/Code/(.+)%i', __DIR__ . '/library/$1.php' );

$_PLUGINS->registerFunction( 'onBeforefieldClass', 'getResponse', FieldTrigger::class );
$_PLUGINS->registerFunction( 'onBeforegetFieldRow', 'getDisplay', FieldTrigger::class );
$_PLUGINS->registerFunction( 'onBeforeprepareFieldDataSave', 'checkValidation', FieldTrigger::class );

$_PLUGINS->registerUserFieldParams();
$_PLUGINS->registerUserFieldTypes( [	'code'					=>	CodeField::class,
										'codemulticheckbox'		=>	CodeSelectField::class,
										'codemultiselect'		=>	CodeSelectField::class,
										'codeselect'			=>	CodeSelectField::class,
										'coderadio'				=>	CodeSelectField::class,
										'codetag'				=>	CodeSelectField::class,
									]);
<?php
namespace CB\Plugin\SignaturePad\Trigger;

defined('CBLIB') or die();

class Register
{
    public static function getFieldTypes( &$types )
    {
        if ( ! is_array($types) ) {
            $types = [];
        }
        $types['cbsignaturepad'] = 'CB\Plugin\SignaturePad\Field\SignaturePadField';
        // No return needed; CB expects $types to be modified by reference.
    }
}

public static function getFieldTypesLegacy( &$types ) {
    if ( ! is_array($types) ) { $types = []; }
    $types['cbsignaturepad'] = 'CB\\Plugin\\SignaturePad\\Field\\SignaturePadField';
}

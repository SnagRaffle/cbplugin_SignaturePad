<?php
namespace CB\Plugin\SignaturePad\Trigger;

defined('CBLIB') or die();

class FieldTrigger
{
    public static function processSave( $field, $user, &$post )
    {
        if ( ! $field || $field->get('type', '') !== 'cbsignaturepad' ) {
            return;
        }

        $fieldName = $field->get('name', '');
        $key       = 'field_' . $fieldName;

        if ( empty($post[$key]) || strpos($post[$key], 'data:image') !== 0 ) {
            return;
        }

        if ( ! preg_match('#^data:image/(png|jpeg);base64,(.+)$#', $post[$key], $m) ) {
            return;
        }

        $ext = ($m[1] === 'jpeg') ? 'jpg' : 'png';
        $bin = base64_decode($m[2]);

        $root = defined('JPATH_SITE') ? JPATH_SITE : (defined('JPATH_ROOT') ? JPATH_ROOT : dirname(__FILE__, 7));
        $dir  = $root . '/images/comprofiler/signatures';

        if ( ! is_dir($dir) ) {
            @mkdir($dir, 0755, true);
        }

        $uid  = (int) ( is_object($user) ? $user->get('id', 0) : 0 );
        $slug = preg_replace('#[^a-z0-9_\-]+#i', '_', $fieldName);
        $name = $uid . '_signature_' . $slug . '_' . date('Ymd_His') . '.' . $ext;
        $path = $dir . '/' . $name;

        if ( @file_put_contents($path, $bin) !== false ) {
            $post[$key] = 'images/comprofiler/signatures/' . $name;
        }
    }
}

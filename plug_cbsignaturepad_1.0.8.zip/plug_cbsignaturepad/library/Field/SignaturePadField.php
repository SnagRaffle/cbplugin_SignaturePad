<?php
namespace CB\Plugin\SignaturePad\Field;

defined('CBLIB') or die();

class SignaturePadField extends \cbFieldHandler
{
    public function getField( &$field, &$user, $output, $reason, $list_compare_types )
    {
        $name   = $field->get('name', '');
        $value  = $this->getFieldValue( $field, $user, 'html', $reason, $list_compare_types );

        if ( $output === 'htmledit' ) {
            if ( $reason === 'search' ) {
                return null;
            }

            $inputName = 'field_' . $name;
            $canvasId  = 'sigpad_' . preg_replace('#[^A-Za-z0-9_\-]#', '_', $name);

            $height = (int) ($field->get('canvas_height', 220) ?: 220);

            $html = '<div class="cb-sigpad">'
                . '<canvas id="' . htmlspecialchars($canvasId) . '" style="border:1px solid #ccc;width:100%;height:' . $height . 'px;"></canvas>'
                . '<div class="mt-2">'
                . '<button type="button" class="btn btn-secondary" onclick="CB_SIGPAD_clear(\'' . htmlspecialchars($canvasId) . '\')">Clear</button> '
                . '<button type="button" class="btn btn-secondary" onclick="CB_SIGPAD_undo(\'' . htmlspecialchars($canvasId) . '\')">Undo</button>'
                . '</div>'
                . '<input type="hidden" name="' . htmlspecialchars($inputName) . '" id="' . htmlspecialchars($canvasId) . '_input" value="" />'
                . '</div>'
                . '<script>(function(){'
                . 'if(!window.CB_SIGPAD_init){'
                . 'window.CB_SIGPAD_canvases={};'
                . 'window.CB_SIGPAD_init=function(id){var c=document.getElementById(id);var ctx=c.getContext("2d");'
                . 'var drawing=false;var stack=[];var ratio=window.devicePixelRatio||1;'
                . 'function resize(){var r=c.getBoundingClientRect();c.width=r.width*ratio;c.height=' . (220) . '*ratio;ctx.setTransform(ratio,0,0,ratio,0,0);ctx.lineCap="round";ctx.lineJoin="round";ctx.lineWidth=2;}'
                . 'resize();window.addEventListener("resize",resize);'
                . 'c.addEventListener("mousedown",function(e){drawing=true;stack.push(ctx.getImageData(0,0,c.width,c.height));ctx.beginPath();ctx.moveTo(e.offsetX,e.offsetY);});'
                . 'c.addEventListener("mousemove",function(e){if(!drawing)return;ctx.lineTo(e.offsetX,e.offsetY);ctx.stroke();});'
                . '["mouseup","mouseleave"].forEach(function(ev){c.addEventListener(ev,function(){drawing=false;});});'
                . 'var input=document.getElementById(id+"_input");var form=c.closest("form");if(form){form.addEventListener("submit",function(){input.value=c.toDataURL("image/png");});}'
                . 'window.CB_SIGPAD_canvases[id]={canvas:c,ctx:ctx,stack:stack};};'
                . 'window.CB_SIGPAD_clear=function(id){var o=window.CB_SIGPAD_canvases[id];if(!o)return;o.ctx.clearRect(0,0,o.canvas.width,o.canvas.height);};'
                . 'window.CB_SIGPAD_undo=function(id){var o=window.CB_SIGPAD_canvases[id];if(!o||!o.stack.length)return;o.ctx.putImageData(o.stack.pop(),0,0);};'
                . '}'
                . 'window.CB_SIGPAD_init("' . htmlspecialchars($canvasId) . '");'
                . '})();</script>';

            return $this->_formatFieldOutput( $name, $html, 'html', false );
        }

        if ( in_array($output, ['html','rss'], true) ) {
            if ( ! $value ) {
                return null;
            }
            $src = htmlspecialchars($value);
            return $this->_formatFieldOutput( $name, '<img alt="Signature" src="' . $src . '" style="max-width:100%;height:auto;" />', $output, false );
        }

        return $this->_formatFieldOutput( $name, $value, $output, true );
    }
}

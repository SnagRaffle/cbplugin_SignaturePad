<?php
/**
 * CB Signature Pad
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */
use CB\Plugin\SignaturePad\Trigger\FieldTrigger;
use CB\Plugin\SignaturePad\Trigger\Register as SigRegister;
use CB\Plugin\SignaturePad\Field\SignaturePadField;
use CBLib\Core\AutoLoader;

defined( 'CBLIB' ) or die();

global $_PLUGINS;

AutoLoader::registerExactMap( '%^CB/Plugin/SignaturePad/(.+)%i', __DIR__ . '/library/$1.php' );

// Save hook
$_PLUGINS->registerFunction( 'onBeforeprepareFieldDataSave', 'processSave', FieldTrigger::class );

// Field params UI
$_PLUGINS->registerUserFieldParams();

// Primary registration method (modern CB)
$_PLUGINS->registerUserFieldTypes( [
    'cbsignaturepad' => SignaturePadField::class,
] );

// Fallback registration for CB builds that aggregate via event
$_PLUGINS->registerFunction( 'onGetUserFieldTypes', 'getFieldTypes', SigRegister::class );

$_PLUGINS->registerFunction( 'onGetFieldTypes', 'getFieldTypes', \CB\Plugin\SignaturePad\Trigger\Register::class );

<?php
defined('CBLIB') or die();

$root = defined('JPATH_SITE') ? JPATH_SITE : (defined('JPATH_ROOT') ? JPATH_ROOT : dirname(__FILE__, 5));
$dir  = $root . '/images/comprofiler/signatures';

if (!is_dir($dir)) {
    @mkdir($dir, 0755, true);
}
if (!file_exists($dir . '/index.html')) {
    @file_put_contents($dir . '/index.html', '<!doctype html><title></title>');
}

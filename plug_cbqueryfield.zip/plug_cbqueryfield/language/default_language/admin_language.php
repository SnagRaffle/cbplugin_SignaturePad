<?php
/**
* Community Builder (TM) cbqueryfield Default (English) language file Administration
* @version $Id:$
* @copyright (C) 2004-2024 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

/**
* WARNING:
* Do not make changes to this file as it will be over-written when you upgrade CB.
* To localize you need to create your own CB language plugin and make changes there.
*/

defined('CBLIB') or die();

return	array(
// 12 language strings from file plug_cbqueryfield/cbqueryfield.xml
'INPUT_SUBSTITUTION_SUPPORTED_QUERY_ADDITIONALLY_SU_d2ab90'	=>	'Input substitution supported Query. Additionally supports [reason] for determining query location and [value] for the currently selected value. Multiple queries can be supplied separated with a ; followed by a linebreak.',
'INPUT_SUBSTITUTION_SUPPORTED_QUERY_ADDITIONALLY_SU_62c8f2'	=>	'Input substitution supported Query. Additionally supports [reason] for determining query location.',
'FIELD_QUERY_VALIDATION_PREFERENCES_14b768'	=>	'Field query validation preferences',
'AUTO_COMPLETE_339610'	=>	'Auto Complete',
'QUERY_CHECK_BOX_MULTIPLE_7c771a'	=>	'Query Check Box (Multiple)',
'NULL_6c3e22'	=>	'NULL',
'OPTIONS_dae8ac'	=>	'Options',
'OPTION_054b4f'	=>	'Option',
'QUERY_DROP_DOWN_MULTISELECT_71e188'	=>	'Query Drop Down (Multi-select)',
'QUERY_DROP_DOWN_SINGLE_SELECT_0d6ec2'	=>	'Query Drop Down (Single Select)',
'QUERY_RADIO_BUTTONS_47ca42'	=>	'Query Radio Buttons',
'QUERY_TAG_aead87'	=>	'Query Tag',
);

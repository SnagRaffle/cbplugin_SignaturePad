<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

use CBLib\Core\AutoLoader;
use CB\Plugin\Query\Field\QueryField;
use CB\Plugin\Query\Field\QuerySelectField;
use CB\Plugin\Query\Trigger\FieldTrigger;

defined( 'CBLIB') or die();

global $_CB_framework, $_PLUGINS;

AutoLoader::registerExactMap( '%^CB/Plugin/Query/(.+)%i', __DIR__ . '/library/$1.php' );

$_PLUGINS->registerFunction( 'onBeforefieldClass', 'getResponse', FieldTrigger::class );
$_PLUGINS->registerFunction( 'onBeforegetFieldRow', 'getDisplay', FieldTrigger::class );
$_PLUGINS->registerFunction( 'onBeforeprepareFieldDataSave', 'checkValidation', FieldTrigger::class );

$_PLUGINS->registerUserFieldParams();
$_PLUGINS->registerUserFieldTypes( [	'query'					=>	QueryField::class,
										'querymulticheckbox'	=>	QuerySelectField::class,
										'querymultiselect'		=>	QuerySelectField::class,
										'queryselect'			=>	QuerySelectField::class,
										'queryradio'			=>	QuerySelectField::class,
										'querytag'				=>	QuerySelectField::class
									]);
<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

use CB\Database\Table\UserTable;
use CB\Database\Table\FieldTable;

defined( 'CBLIB' ) or die();

/**
 * @var array        $fieldGroups
 * @var array        $rows
 * @var int          $row
 * @var array        $fields
 * @var FieldTable[] $groupedFields
 * @var FieldTable   $groupedField
 * @var string       $display
 *
 * @var FieldTable   $field
 * @var UserTable    $user
 * @var string       $output
 * @var string       $reason
 * @var int          $list_compare_types
 */

echo $display;
<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

use CB\Database\Table\UserTable;
use CB\Database\Table\FieldTable;

defined( 'CBLIB' ) or die();

/**
 * @var array      $fieldGroups
 * @var array      $rows
 * @var array      $rowsTitles
 * @var array      $rowsDescriptions
 * @var array      $rowsFields
 *
 * @var FieldTable $field
 * @var UserTable  $user
 * @var string     $output
 * @var string     $reason
 * @var int        $list_compare_types
 */

if ( ! $rows ) {
	return;
}
?>
<div class="form-group mb-0 cbFieldGroup cbFieldGroupDefault">
	<?php echo implode( '<hr class="' . ( $reason === 'list' ? 'mt-1 mb-1' : 'mt-3 mb-3' ) . '" />', $rows ); ?>
</div>

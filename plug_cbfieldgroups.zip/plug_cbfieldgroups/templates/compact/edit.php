<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

use CB\Database\Table\UserTable;
use CB\Database\Table\FieldTable;
use CB\Plugin\FieldGroups\CBFieldGroups;

defined( 'CBLIB' ) or die();

/**
 * @var array      $fieldGroups
 * @var string     $repeatLabel
 * @var bool       $repeatOrdering
 * @var bool       $repeatCount
 * @var int        $repeatMax
 * @var array      $rows
 * @var array      $rowsTitles
 * @var array      $rowsDescriptions
 * @var array      $rowsFields
 *
 * @var FieldTable $field
 * @var UserTable  $user
 * @var string     $output
 * @var string     $reason
 * @var int        $list_compare_types
 */
?>
<div class="form-group mb-0 mw-100 cbRepeat cbFieldGroup cbFieldGroupCompact" data-cbrepeat-fallback-for="<?php echo htmlspecialchars( $field->getString( 'name', '' ) ); ?>" data-cbrepeat-fallback-name="<?php echo htmlspecialchars( $field->getString( 'name', '' ) ); ?>" <?php echo ( ! $repeatOrdering ? ' data-cbrepeat-sortable="false"' : null ) . ( $repeatMax ? ' data-cbrepeat-max="' . (int) $repeatMax . '"' : null ); ?>>
	<?php echo implode( '', $rows ); ?>
	<input type="hidden" name="<?php echo CBFieldGroups::getGroupedName( $field->getString( 'name', '' ), null, 'count' ); ?>" class="cbRepeatCount" />
</div>

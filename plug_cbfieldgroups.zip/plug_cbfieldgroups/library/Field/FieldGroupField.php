<?php
/**
 * Community Builder (TM)
 * @version $Id: $
 * @package CommunityBuilder
 * @copyright (C) 2004-2023 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

namespace CB\Plugin\FieldGroups\Field;

use CB\Database\Table\UserTable;
use CB\Database\Table\FieldTable;
use CBLib\Application\Application;
use CBLib\Language\CBTxt;
use CB\Plugin\FieldGroups\CBFieldGroups;
use CBLib\Registry\Registry;

\defined( 'CBLIB' ) or die();

class FieldGroupField extends \cbFieldHandler
{

	/**
	 * Accessor:
	 * Returns a field in specified format
	 *
	 * @param  FieldTable  $field
	 * @param  UserTable   $user
	 * @param  string      $output               'html', 'xml', 'json', 'php', 'csvheader', 'csv', 'rss', 'fieldslist', 'htmledit'
	 * @param  string      $reason               'profile' for user profile view, 'edit' for profile edit, 'register' for registration, 'search' for searches
	 * @param  int         $list_compare_types   IF reason == 'search' : 0 : simple 'is' search, 1 : advanced search with modes, 2 : simple 'any' search
	 * @return mixed
	 */
	public function getField( &$field, &$user, $output, $reason, $list_compare_types )
	{
		global $_CB_framework, $_PLUGINS, $ueConfig;

		$fieldName								=	$field->getString( 'name', '' );

		switch ( $output ) {
			case 'html':
			case 'rss':
				$template						=	$field->params->getString( 'repeat_template', '' );
				$customTemplate					=	CBTxt::T( $field->params->getRaw( 'repeat_template_custom', '' ) );
				$fieldFormatting				=	$field->params->getString( 'repeat_formatting', 'div' );
				$showEmptyFields				=	$field->params->getString( 'repeat_empty_fields', '' );
				$showEmptyFieldCurrent			=	Application::Config()->getInt( 'showEmptyFields', 1 );

				if ( $showEmptyFields !== '' ) {
					$ueConfig['showEmptyFields']	=	(int) $showEmptyFields;
				}

				$dummyUser						=	clone $user;

				$dummyUser->set( '_isFieldGroup', true );

				$hiddenPositions				=	[ 'not_on_profile_1', 'not_on_profile_2', 'not_on_profile_3', 'not_on_profile_4', 'not_on_profile_5', 'not_on_profile_6', 'not_on_profile_7', 'not_on_profile_8', 'not_on_profile_9' ];

				if ( $reason === 'profile' ) {
					$availableTabs				=	\CBuser::getInstance( $user->getInt( 'id', 0 ), false )->_getCbTabs( false )->_getTabsDb( $user, $reason );
				} else {
					$availableTabs				=	[];
				}

				$fieldGroups					=	CBFieldGroups::getGroupedFields( $field, $dummyUser, $reason );
				$rowCount						=	\count( $fieldGroups );
				$rows							=	[];
				$rowsTitles						=	[];
				$rowsDescriptions				=	[];
				$rowsFields						=	[];
				$number							=	0;

				foreach ( $fieldGroups as $row => $groupedFields ) {
					/** @var FieldTable[] $groupedFields */
					$cbUser						=	CBFieldGroups::mapGroupedColumns( $groupedFields, $dummyUser );
					$titles						=	[];
					$descriptions				=	[];
					$fields						=	[];
					$extras						=	[ 'row_number' => ++$number, 'row_count' => $rowCount ];

					foreach ( $groupedFields as $groupedField ) {
						$groupedFieldTab		=	$groupedField->getInt( 'tabid', 0 );

						if ( ( $reason === 'profile' )
							 && ( $groupedFieldTab !== $field->getInt( 'tabid', 0 ) )
							 && isset( $availableTabs[$groupedFieldTab] )
							 && \in_array( $availableTabs[$groupedFieldTab]->getString( 'position', '' ), $hiddenPositions, true ) ) {
							// The grouped field is on a different tab that's in a not shown on profile position so lets respect that and hide it from profile view:
							continue;
						}

						$groupedFieldType		=	$groupedField->getString( 'type', '' );
						$groupedFieldName		=	$groupedField->getString( '_name', '' );

						$title					=	( $_PLUGINS->callField( $groupedFieldType, 'getFieldTitle', [ &$groupedField, &$dummyUser, $output, $reason ], $groupedField ) ?? '' );
						$description			=	( $_PLUGINS->callField( $groupedFieldType, 'getFieldDescription', [ &$groupedField, &$dummyUser, $output, $reason ], $groupedField ) ?? '' );
						$display				=	( $_PLUGINS->callField( $groupedFieldType, 'getFieldRow', [ &$groupedField, &$dummyUser, $output, $fieldFormatting, $reason, $list_compare_types ], $groupedField ) ?? '' );

						if ( ( $groupedFieldType === 'image' ) && ( strpos( $display, 'cbImagePendingApprovalButtons' ) !== false ) ) {
							$imgApprove			=	$_CB_framework->viewUrl( 'fieldclass', true, [ 'field' => $field->getString( 'name', '' ), 'function' => 'image_approve', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason, 'index' => $row, 'image' => $groupedFieldName ] );
							$imgReject			=	$_CB_framework->viewUrl( 'fieldclass', true, [ 'field' => $field->getString( 'name', '' ), 'function' => 'image_reject', 'user' => $user->getInt( 'id', 0 ), 'reason' => $reason, 'index' => $row, 'image' => $groupedFieldName ] );

							$imgApproval		=	'<div class="cbImagePendingApprovalButtons">'
												.		'<a href="' . $imgApprove . '" class="btn btn-sm btn-success cbImagePendingApprovalAccept">' . CBTxt::Th( 'UE_APPROVE', 'Approve' ) . '</a>'
												.		' <a href="' . $imgReject . '" class="btn btn-sm btn-danger cbImagePendingApprovalReject">' . CBTxt::Th( 'UE_REJECT', 'Reject' ) . '</a>'
												.	'</div>';

							$display			=	preg_replace( '%<div class="cbImagePendingApprovalButtons">.+</div>%iU', $imgApproval, $display );
						}

						ob_start();
						require CBFieldGroups::getTemplate( $template, 'display_field' );
						$html					=	ob_get_clean();

						if ( trim( $html ) !== '' ) {
							$titles[$groupedFieldName]						=	$title;
							$descriptions[$groupedFieldName]				=	$description;
							$fields[$groupedFieldName]						=	$html;
						}

						if ( $customTemplate ) {
							// Always build the substitutions even if empty:
							$extras['title_' . $groupedFieldName]			=	$title;
							$extras['description_' . $groupedFieldName]		=	$description;
							$extras['field_' . $groupedFieldName]			=	( trim( $html ) !== '' ? $html : '' );
						}
					}

					if ( $customTemplate && $fields ) {
						// Replace the fields array that's about to be imploded with the single custom template usage:
						$fields					=	[];
						$fields[]				=	$cbUser->replaceUserVars( $customTemplate, false, false, $extras, false );
					}

					ob_start();
					require CBFieldGroups::getTemplate( $template, 'display_row' );
					$html						=	ob_get_clean();

					if ( trim( $html ) !== '' ) {
						$rows[]					=	$html;
						$rowsTitles[]			=	$titles;
						$rowsDescriptions[]		=	$descriptions;
						$rowsFields[]			=	$fields;
					}

					// Revert the cached user object change:
					$cbUser->_cbuser			=	$user;
				}

				$dummyUser->set( '_isFieldGroup', false );

				ob_start();
				require CBFieldGroups::getTemplate( $template, 'display' );
				$html							=	ob_get_clean();

				if ( $showEmptyFields !== '' ) {
					$ueConfig['showEmptyFields']	=	$showEmptyFieldCurrent;
				}

				return $this->formatFieldValueLayout( $this->_formatFieldOutput( $fieldName, $html, $output, false ), $reason, $field, $user, false );
			case 'htmledit':
				$template						=	$field->params->getString( 'repeat_template_edit', '' );
				$customTemplate					=	CBTxt::T( $field->params->getRaw( 'repeat_template_edit_custom', '' ) );
				$fieldFormatting				=	$field->params->getString( 'repeat_formatting_edit', 'div' );

				if ( ! $template ) {
					$template					=	$field->params->getString( 'repeat_template', '' );
				}

				if ( $reason === 'search' ) {
					if ( ! CBFieldGroups::canSearch() ) {
						return null;
					}

					$dummyUser					=	clone $user; // using a dummy user object to avoid real user object being altered during grouped field parsing

					$dummyUser->set( '_isFieldGroup', true );

					$fieldGroups				=	CBFieldGroups::getGroupedFields( $field, $dummyUser, $reason );

					$rows						=	[];
					$rowsTitles					=	[];
					$rowsDescriptions			=	[];
					$rowsFields					=	[];

					foreach ( $fieldGroups as $row => $groupedFields ) {
						/** @var FieldTable[] $groupedFields */
						$cbUser					=	CBFieldGroups::mapGroupedColumns( $groupedFields, $dummyUser );
						$titles					=	[];
						$descriptions			=	[];
						$fields					=	[];

						foreach ( $groupedFields as $groupedField ) {
							$title				=	( $_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'getFieldTitle', [ &$groupedField, &$dummyUser, $output, $reason ], $groupedField ) ?? '' );
							$description		=	( $_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'getFieldDescription', [ &$groupedField, &$dummyUser, $output, $reason ], $groupedField ) ?? '' );
							$edit				=	( $_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'getFieldRow', [ &$groupedField, &$dummyUser, $output, 'div', $reason, $list_compare_types ], $groupedField ) ?? '' );

							ob_start();
							require CBFieldGroups::getTemplate( $template, 'search_field' );
							$html				=	ob_get_clean();

							if ( trim( $html ) !== '' ) {
								$groupedFieldName					=	$groupedField->getString( '_name', '' );

								$titles[$groupedFieldName]			=	$title;
								$descriptions[$groupedFieldName]	=	$description;
								$fields[$groupedFieldName]			=	$html;
							}
						}

						ob_start();
						require CBFieldGroups::getTemplate( $template, 'search_row' );
						$html					=	ob_get_clean();

						if ( trim( $html ) !== '' ) {
							$rows[]				=	$html;
							$rowsTitles[]		=	$titles;
							$rowsDescriptions[]	=	$descriptions;
							$rowsFields[]		=	$fields;
						}

						// Revert the cached user object change:
						$cbUser->_cbuser		=	$user;

						break; // Only first row is relevant so stop here
					}

					$dummyUser->set( '_isFieldGroup', false );

					ob_start();
					require CBFieldGroups::getTemplate( $template, 'search' );
					$html						=	ob_get_clean();

					return $this->formatFieldValueLayout( $this->_formatFieldOutput( $fieldName, $html, $output, false ), $reason, $field, $user, false );
				}

				// TODO: this doesn't render right after a POST failed validation error.. all the values are lost!
				static $editRepeat			=	0;

				if ( ! $editRepeat++ ) {
					$_CB_framework->outputCbJQuery( "$( '.cbRepeat' ).cbrepeat();", 'cbrepeat' );
				}

				$dummyUser					=	clone $user; // using a dummy user object to avoid real user object being altered during grouped field parsing

				$dummyUser->set( '_isFieldGroup', true );

				$fieldGroups				=	CBFieldGroups::getGroupedFields( $field, $dummyUser, $reason );

				$repeatLabel				=	CBTxt::T( $field->params->getString( 'repeat_label', '' ) );
				$repeatOrdering				=	$field->params->getBool( 'repeat_ordering', false );
				$repeatCount				=	$field->params->getBool( 'repeat_multiple', false );
				$repeatMax					=	$field->params->getInt( 'repeat_limit', 5 );

				if ( ! $repeatLabel ) {
					if ( $repeatCount ) {
						$repeatLabel		=	CBTxt::T( 'Add Rows' );
					} else {
						$repeatLabel		=	CBTxt::T( 'Add Row' );
					}
				}

				$rows						=	[];
				$rowsTitles					=	[];
				$rowsDescriptions			=	[];
				$rowsFields					=	[];
				$editorFields				=	[];

				foreach ( $fieldGroups as $row => $groupedFields ) {
					/** @var FieldTable[] $groupedFields */
					$cbUser					=	CBFieldGroups::mapGroupedColumns( $groupedFields, $dummyUser );
					$titles					=	[];
					$descriptions			=	[];
					$fields					=	[];
					$extras					=	[];

					foreach ( $groupedFields as $groupedField ) {
						$title				=	( $_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'getFieldTitle', [ &$groupedField, &$dummyUser, $output, $reason ], $groupedField ) ?? '' );
						$description		=	( $_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'getFieldDescription', [ &$groupedField, &$dummyUser, $output, $reason ], $groupedField ) ?? '' );
						$edit				=	( $_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'getFieldRow', [ &$groupedField, &$dummyUser, $output, $fieldFormatting, $reason, $list_compare_types ], $groupedField ) ?? '' );

						ob_start();
						require CBFieldGroups::getTemplate( $template, 'edit_field' );
						$html				=	ob_get_clean();

						$groupedFieldName									=	$groupedField->getString( '_name', '' );

						if ( trim( $html ) !== '' ) {
							if ( $groupedField->getString( 'type', '' ) === 'editorta' ) {
								$editorFields[$groupedFieldName]			=	$groupedField;
							}

							$titles[$groupedFieldName]						=	$title;
							$descriptions[$groupedFieldName]				=	$description;
							$fields[$groupedFieldName]						=	$html;
						}

						if ( $customTemplate ) {
							// Always build the substitutions even if empty:
							$extras['title_' . $groupedFieldName]			=	$title;
							$extras['description_' . $groupedFieldName]		=	$description;
							$extras['field_' . $groupedFieldName]			=	( trim( $html ) !== '' ? $html : '' );
						}
					}

					if ( $customTemplate && $fields ) {
						// Replace the fields array that's about to be imploded with the single custom template usage:
						$fields				=	[];
						$fields[]			=	$cbUser->replaceUserVars( $customTemplate, false, false, $extras, false );
					}

					ob_start();
					require CBFieldGroups::getTemplate( $template, 'edit_row' );
					$html					=	ob_get_clean();

					if ( trim( $html ) !== '' ) {
						$rows[]				=	$html;
						$rowsTitles[]		=	$titles;
						$rowsDescriptions[]	=	$descriptions;
						$rowsFields[]		=	$fields;
					}

					// Revert the cached user object change:
					$cbUser->_cbuser		=	$user;
				}

				$dummyUser->set( '_isFieldGroup', false );

				ob_start();
				require CBFieldGroups::getTemplate( $template, 'edit' );
				$html						=	ob_get_clean();

				if ( $editorFields ) {
					$js						=	null;

					if ( stripos( $html, 'tinymce' ) !== false ) {
						static $tinyMCE		=	0;

						if ( ! $tinyMCE++ ) {
							$js				.=	"$( '.cbRepeat.cbFieldGroup' ).on( 'cbrepeat.add', function() {"
											.		"try {"
											.			"Joomla.JoomlaTinyMCE.setupEditors();"
											.		"} catch ( e ) {}"
											.	"}).find( 'textarea.mce_editable' ).on( 'cloning', function() {"
											.		"try {"
											.			"tinymce.remove();"
											.		"} catch ( e ) {}"
											.	"});";
						}
					} elseif ( stripos( $html, 'codemirror' ) !== false ) {
						static $codeMirror	=	0;

						if ( ! $codeMirror++ ) {
							$js				.=	"$( '.cbRepeat.cbFieldGroup' ).on( 'cbrepeat.add', function() {"
											.		"try {"
											.			"$( this ).find( 'textarea.codemirror-source' ).each( function() {"
											.				"var input = $( this ).removeClass( 'codemirror-source' );"
											.				"var id = input.prop( 'id' );"
											.				"Joomla.editors.instances[id] = CodeMirror.fromTextArea( this, input.data( 'options' ) );"
											.			"});"
											.		"} catch ( e ) {}"
											.	"}).find( 'textarea[data-options]' ).on( 'cloning', function() {"
											.		"try {"
											.			"var id = $( this ).prop( 'id' );"
											.			"if ( typeof Joomla.editors.instances[id] != 'undefined' ) {"
											.				"Joomla.editors.instances[id].toTextArea();"
											.			"}"
											.			"$( this ).addClass( 'codemirror-source' );"
											.		"} catch ( e ) {}"
											.	"});";
						}
					} elseif ( stripos( $html, 'wf-editor' ) !== false ) {
						static $JCE			=	0;

						if ( ! $JCE++ ) {
							$js				.=	"var JCECloning = false;"
											.	"$( '.cbRepeat.cbFieldGroup' ).on( 'cbrepeat.add', function() {"
											.		"try {"
											.			"if ( ! JCECloning ) {"
											.				"JCECloning = true;"
											.				"$( 'textarea.wf-editor' ).each( function() {"
											.					"$( this ).val( WFEditor.getContent( $( this ).prop( 'id' ) ) );"
											.					"$( this ).insertAfter( $( this ).parent() );"
											.					"$( this ).siblings( '.wf-editor-container' ).remove();"
											.					"$( this ).show();"
											.				"});"
											.				"tinymce.editors = [];"
											.				"WFEditor.load();"
											.				"setTimeout( function() {"
											.					"JCECloning = false;"
											.				"}, 1000 );"
											.			"}"
											.		"} catch ( e ) {}"
											.	"});";
						}
					}

					$_CB_framework->outputCbJQuery( $js );
				}

				return $this->formatFieldValueLayout( $this->_formatFieldOutput( $fieldName, $html, $output, false ), $reason, $field, $user, false )
					   . $this->_fieldIconsHtml( $field, $user, $output, $reason, null, 'html', null, null, [], true, 0 );
			default:
				return $this->_formatFieldOutput( $fieldName, $user->getRaw( $fieldName ), $output, false );
		}
	}

	/**
	 * Mutator:
	 * Prepares field data for saving to database (safe transfer from $postdata to $user)
	 * Override
	 *
	 * @param  FieldTable  $field
	 * @param  UserTable   $user      RETURNED populated: touch only variables related to saving this field (also when not validating for showing re-edit)
	 * @param  array       $postdata  Typically $_POST (but not necessarily), filtering required.
	 * @param  string      $reason    'edit' for save user edit, 'register' for save registration
	 */
	public function prepareFieldDataSave( &$field, &$user, &$postdata, $reason )
	{
		global $_PLUGINS;

		$this->_prepareFieldMetaSave( $field, $user, $postdata, $reason );

		$dummyPostData							=	$postdata;
		$dummyUser								=	clone $user; // using a dummy user object to avoid real user object being altered during grouped field parsing

		$dummyUser->set( '_isFieldGroup', true );

		foreach ( $field->getTableColumns() as $col ) {
			$oldValues							=	[];
			$existingValues						=	$user->getRaw( $col );

			if ( $existingValues ) {
				$existingValues					=	new Registry( $existingValues );
				$oldValues						=	$existingValues->asArray();
			}

			$fields								=	CBFieldGroups::getGroupedFields( $field, $dummyUser, $reason, $dummyPostData );
			$values								=	[];
			$rowNumber							=	0;

			$_PLUGINS->trigger( 'fieldgroups_onBeforePrepareFieldDataSave', [ $field, &$fields, $oldValues, &$values, &$dummyUser, &$dummyPostData, $reason ] );

			// Make sure the fields posted are allowed and validated:
			foreach ( $fields as $i => $groupedFields ) {
				/** @var FieldTable[] $groupedFields */
				++$rowNumber;

				$cbUser							=	CBFieldGroups::mapGroupedColumns( $groupedFields, $dummyUser, $dummyPostData );

				foreach ( $groupedFields as $groupedField ) {
					$title						=	$groupedField->getString( 'title', '' );

					$groupedField->set( 'title', CBTxt::T( 'FIELDGROUP_VALIDATION_TITLE', '[title] : Row [row] : [field]', [ '[title]' => $this->getFieldTitle( $field, $user, 'text', $reason ), '[row]' => $rowNumber, '[field]' => $title ] ) );

					$_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'prepareFieldDataSave', [ &$groupedField, &$dummyUser, &$dummyPostData, $reason ], $groupedField );

					$groupedField->set( 'title', $title );

					// Validation and storage processing passed so lets update the values to be stored:
					foreach ( $groupedField->getRaw( '_tablecolumns', [] ) as $oldCol => $newCol ) {
						$newValue				=	$dummyUser->getRaw( $newCol );

						if ( $groupedField->getString( 'type', '' ) === 'fieldgroup' ) {
							$newValue			=	json_decode( $newValue, true );
						}

						$values[$i][$oldCol]	=	$newValue; // Already sanitized by prepareFieldDataSave or getGroupedFields
					}
				}

				// Revert the postdata and cached user object change:
				$cbUser->_cbuser				=	$user;
			}

			$_PLUGINS->trigger( 'fieldgroups_onAfterPrepareFieldDataSave', [ $field, &$fields, $oldValues, &$values, &$user, &$dummyPostData, $reason ] );

			$value								=	json_encode( $values );

			if ( $this->validate( $field, $user, $col, $value, $dummyPostData, $reason ) ) {
				if ( isset( $user->$col ) && ( (string) $user->$col ) !== (string) $value ) {
					$this->_logFieldUpdate( $field, $user, $reason, $user->$col, $value );
				}
			}

			$user->$col							=	$value;
		}

		$dummyUser->set( '_isFieldGroup', false );
	}

	/**
	 * Mutator:
	 * Prepares field data commit
	 * Override
	 *
	 * @param  FieldTable  $field
	 * @param  UserTable   $user      RETURNED populated: touch only variables related to saving this field (also when not validating for showing re-edit)
	 * @param  array       $postdata  Typically $_POST (but not necessarily), filtering required.
	 * @param  string      $reason    'edit' for save user edit, 'register' for save registration
	 */
	public function commitFieldDataSave( &$field, &$user, &$postdata, $reason )
	{
		global $_PLUGINS;

		$dummyPostData							=	$postdata;
		$dummyUser								=	clone $user; // using a dummy user object to avoid real user object being altered during grouped field parsing

		$dummyUser->set( '_isFieldGroup', true );

		foreach ( $field->getTableColumns() as $col ) {
			$oldValues							=	[];
			$existingValues						=	$user->getRaw( $col );

			if ( $existingValues ) {
				$existingValues					=	new Registry( $existingValues );
				$oldValues						=	$existingValues->asArray();
			}

			$fields								=	CBFieldGroups::getGroupedFields( $field, $dummyUser, $reason );
			$values								=	[];
			$rowNumber							=	0;

			$_PLUGINS->trigger( 'fieldgroups_onBeforeCommitFieldDataSave', [ $field, &$fields, $oldValues, &$values, &$dummyUser, &$dummyPostData, $reason ] );

			foreach ( $fields as $i => $groupedFields ) {
				/** @var FieldTable[] $groupedFields */
				++$rowNumber;

				$cbUser							=	CBFieldGroups::mapGroupedColumns( $groupedFields, $dummyUser, $dummyPostData );

				foreach ( $groupedFields as $groupedField ) {
					$title						=	$groupedField->getString( 'title', '' );

					$groupedField->set( 'title', CBTxt::T( 'FIELDGROUP_VALIDATION_TITLE', '[title] : Row [row] : [field]', [ '[title]' => $this->getFieldTitle( $field, $user, 'text', $reason ), '[row]' => $rowNumber, '[field]' => $title ] ) );

					$_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'commitFieldDataSave', [ &$groupedField, &$dummyUser, &$dummyPostData, $reason ], $groupedField );

					$groupedField->set( 'title', $title );

					// Validation and storage processing passed so lets update the values to be stored:
					foreach ( $groupedField->getRaw( '_tablecolumns', [] ) as $oldCol => $newCol ) {
						$newValue				=	$dummyUser->getRaw( $newCol );

						if ( $groupedField->getString( 'type', '' ) === 'fieldgroup' ) {
							$newValue			=	json_decode( $newValue, true );
						}

						$values[$i][$oldCol]	=	$newValue; // Already sanitized by commitFieldDataSave, prepareFieldDataSave, or getGroupedFields
					}
				}

				// Revert the cached user object change:
				$cbUser->_cbuser				=	$user;
			}

			$_PLUGINS->trigger( 'fieldgroups_onAfterCommitFieldDataSave', [ $field, &$fields, $oldValues, &$values, &$user, &$dummyPostData, $reason ] );

			$value								=	json_encode( $values );

			// Only update if fields changed the values in their commitFieldDataSave behavior:
			if ( isset( $user->$col ) && ( (string) $user->$col ) !== (string) $value ) {
				if ( $this->validate( $field, $user, $col, $value, $dummyPostData, $reason ) ) {
					$this->_logFieldUpdate( $field, $user, $reason, $user->$col, $value );

					$user->$col					=	$value;
				}
			}
		}

		$dummyUser->set( '_isFieldGroup', false );
	}

	/**
	 * Mutator:
	 * Prepares field data rollback
	 * Override
	 *
	 * @param  FieldTable  $field
	 * @param  UserTable   $user      RETURNED populated: touch only variables related to saving this field (also when not validating for showing re-edit)
	 * @param  array       $postdata  Typically $_POST (but not necessarily), filtering required.
	 * @param  string      $reason    'edit' for save user edit, 'register' for save registration
	 */
	public function rollbackFieldDataSave( &$field, &$user, &$postdata, $reason )
	{
		global $_PLUGINS;

		$dummyPostData				=	$postdata;
		$dummyUser					=	clone $user; // using a dummy user object to avoid real user object being altered during grouped field parsing

		$dummyUser->set( '_isFieldGroup', true );

		foreach ( $field->getTableColumns() as $col ) {
			$fields					=	CBFieldGroups::getGroupedFields( $field, $dummyUser, $reason );
			$rowNumber				=	0;

			foreach ( $fields as $groupedFields ) {
				/** @var FieldTable[] $groupedFields */
				++$rowNumber;

				$cbUser				=	CBFieldGroups::mapGroupedColumns( $groupedFields, $dummyUser, $dummyPostData );

				foreach ( $groupedFields as $groupedField ) {
					$title			=	$groupedField->getString( 'title', '' );

					$groupedField->set( 'title', CBTxt::T( 'FIELDGROUP_VALIDATION_TITLE', '[title] : Row [row] : [field]', [ '[title]' => $this->getFieldTitle( $field, $user, 'text', $reason ), '[row]' => $rowNumber, '[field]' => $title ] ) );

					$_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'rollbackFieldDataSave', [ &$groupedField, &$dummyUser, &$dummyPostData, $reason ], $groupedField );

					$groupedField->set( 'title', $title );
				}

				// Revert the cached user object change:
				$cbUser->_cbuser	=	$user;
			}

			$_PLUGINS->trigger( 'fieldgroups_onAfterRollbackFieldDataSave', [ $field, &$fields, &$user, &$dummyPostData, $reason ] );
		}

		$dummyUser->set( '_isFieldGroup', false );
	}

	/**
	 * Finder:
	 * Prepares field data for saving to database (safe transfer from $postdata to $user)
	 * Override
	 *
	 * @param  FieldTable  $field
	 * @param  UserTable   $searchVals          RETURNED populated: touch only variables related to saving this field (also when not validating for showing re-edit)
	 * @param  array       $postdata            Typically $_POST (but not necessarily), filtering required.
	 * @param  int         $list_compare_types  IF reason == 'search' : 0 : simple 'is' search, 1 : advanced search with modes, 2 : simple 'any' search
	 * @param  string      $reason              'edit' for save user edit, 'register' for save registration
	 * @return \cbSqlQueryPart[]
	 */
	public function bindSearchCriteria( &$field, &$searchVals, &$postdata, $list_compare_types, $reason )
	{
		global $_PLUGINS;

		if ( ! CBFieldGroups::canSearch() ) {
			return [];
		}

		$user									=	\CBuser::getMyUserDataInstance();
		$searchOperator							=	$field->params->getInt( 'repeat_search_operator', 0 );

		$dummyPostData							=	$postdata;
		$dummySearchVals						=	new \stdClass();
		$query									=	[];

		foreach ( $field->getTableColumns() as $col ) {
			$groupedName						=	CBFieldGroups::getGroupedName( $col );

			$sql								=	new \cbSqlQueryPart();
			$sql->tag							=	'json';
			$sql->name							=	$col;
			$sql->table							=	$field->getString( 'table' );
			$sql->type							=	'sql:operator';
			$sql->operator						=	( $searchOperator === 1 ? 'OR' : ( $searchOperator === 2 ? 'AND' : ( $list_compare_types === 0 ? 'AND' : 'OR' ) ) );
			$sql->searchmode					=	'is';
			$sql->children						=	[];

			// Find all the post data relevant to this field group:
			foreach ( $postdata as $k => $v ) {
				if ( strpos( $k, $groupedName ) !== 0 ) {
					continue;
				}

				// Map to the original field as well to handle substitutions cases:
				$oldName						=	str_replace( $groupedName . '__0__', '', $k );

				$dummyPostData[$oldName]		=	$v;
			}

			$paths								=	[];

			foreach ( CBFieldGroups::getGroupedFields( $field, $user, $reason, $dummyPostData ) as $groupedFields ) {
				/** @var FieldTable[] $groupedFields */
				foreach ( $groupedFields as $name => $groupedField ) {
					$groupedField->set( 'table', $field->getString( 'table' ) );

					$groupedFieldSearches			=	( $_PLUGINS->callField( $groupedField->getString( 'type', '' ), 'bindSearchCriteria', [ &$groupedField, &$dummySearchVals, &$dummyPostData, $list_compare_types, $reason ], $groupedField ) ?? [] );

					if ( \count( $_PLUGINS->getErrorMSG( false ) ) ) {
						break;
					}

					if ( ( ! \is_array( $groupedFieldSearches ) ) || ( ! \count( $groupedFieldSearches ) ) ) {
						continue;
					}

					$sql->children					=	$groupedFieldSearches;

					if ( $groupedField->getString( 'type', '' ) === 'fieldgroup' ) {
						if ( ! $groupedFieldSearches[0]->paths ) {
							continue;
						}

						$sql->addChildren( $groupedFieldSearches[0]->children );

						foreach( $groupedFieldSearches[0]->paths as $pathName => $path ) {
							$paths[$pathName]		=	'$**.' . $name . '.*.' . substr( $path, 4 );
						}
					} else {
						$groupedFieldName			=	$groupedField->getString( 'name', '' );

						$sql->addChildren( $groupedFieldSearches );

						$paths[$groupedFieldName]	=	'$**.' . $name;
					}

					foreach ( $dummySearchVals as $k => $v ) {
						$searchVals->$k				=	$v;
					}
				}

				break; // Only first row is relevant so stop here
			}

			if ( $paths ) {
				$sql->paths						=	$paths;

				$query[]						=	$sql;
			}
		}

		return $query;
	}
	
	/**
	 * Direct access to field for custom operations, like for Ajax
	 *
	 * WARNING: direct unchecked access, except if $user is set, then check well for the $reason ...
	 *
	 * @param  FieldTable  $field
	 * @param  UserTable    $user
	 * @param  array                 $postdata
	 * @param  string                $reason     'profile' for user profile view, 'edit' for profile edit, 'register' for registration, 'search' for searches (always public!)
	 * @return string                            Expected output.
	 */
	public function fieldClass( &$field, &$user, &$postdata, $reason )
	{
		$function					=	$this->getInput()->getString( 'function', '' );

		switch ( $function ) {
			case 'image_approve':
			case 'image_reject':
				$index				=	$this->getInput()->getInt( 'index' );
				$image				=	$this->getInput()->getString( 'image', '' );

				if ( ( $index === null ) || ( ! $image ) ) {
					break;
				}

				$values				=	new Registry( $user->getRaw( $field->getString( 'name', '' ) ) );

				if ( ! $values->has( $index . '.' . $image ) ) {
					break;
				}

				$approved			=	$values->getInt( $index . '.' . $image . 'approved', 0 );

				if ( $approved ) {
					break;
				}

				if ( $function === 'image_reject' ) {
					$values->set( $index . '.' . $image, '' );
				}

				$values->set( $index . '.' . $image . 'approved', 1 );

				if ( ! $user->storeDatabaseValue( $field->getString( 'name', '' ), $values->asJson() ) ) {
					cbRedirectToProfile( $user->getInt( 'id', 0 ), $user->getError() );

					return false;
				}

				$cbNotification		=	new \cbNotification();

				if ( $function === 'image_reject' ) {
					$cbNotification->sendFromSystem( $user, CBTxt::T( 'UE_IMAGEREJECTED_SUB', 'Image Rejected' ), CBTxt::T( 'UE_IMAGEREJECTED_MSG', 'Your image has been rejected by a moderator. Please log in and submit a new image.' ) );
				} else {
					$cbNotification->sendFromSystem( $user, CBTxt::T( 'UE_IMAGEAPPROVED_SUB', 'Image Approved' ), CBTxt::T( 'UE_IMAGEAPPROVED_MSG', 'Your image has been approved by a moderator.' ) );
				}

				cbRedirectToProfile( $user->getInt( 'id', 0 ), CBTxt::Th( 'UE_USERIMAGEMODERATED_SUCCESSFUL', 'User Image Successfully Moderated!' ) );

				return false;
		}

		parent::fieldClass( $field, $user, $postdata, $reason );

		return false;
	}
}